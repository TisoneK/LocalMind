# Inefficiency Log (append-only, mandatory)

Every session appends one block — honestly. Friction you absorb silently
is friction the next agent hits blind. "None this session" is valid only
if literally nothing slowed you down.

---
## 2026-08-23 — Buffy / z-ai/glm-5.2 (Session 377)

- **Problem:** `pip install -e '.[dev]'` from `backend/` failed on the user's Windows machine at "Preparing editable metadata" with `ValueError: Readme path must be within the project directory: ../README.md` — the backend package's pyproject.toml pointed `readme`/`license` outside the package dir.
- **Cost:** Blocked backend setup entirely; only reproducible via a fresh-venv install because the committed backend venv on the dev machine already had a `.pth` editable install (no pip binary), masking the breakage locally. Hatchling (any OS) rejects out-of-tree paths.
- **Cause:** `readme = "../README.md"` + `license = { file = "../LICENSE" }` in `backend/pyproject.toml` — hatchling requires them inside the project directory.
- **Workaround / fix:** Added `backend/README.md` (package-local readme pointing at the repo root README) + `backend/LICENSE` (MIT copy); `pyproject.toml` now references those. Verified with a clean throwaway venv: `pip install -e '.[dev]'` metadata step + wheel build now succeed.
- **Prevent next time:** Keep every path a backend `pyproject.toml` references inside `backend/`; when asked to fix a `pip install` failure, reproduce it in a fresh venv (the existing venv may hide it).

---
## 2026-07-09 — Super Z / GLM-4.5 (Session 1)

- **Problem:** `pip install -e ".[dev]"` failed with `externally-managed-environment` error on sysstem Python.
- **Cost:** One full round-trip with the user (agent reported "PAT is a placeholder", user had to paste it in chat).
- **Cause:** The IM gateway / file-upload pipeline scrubs secrets from uploaded files before they reach the agent.
- **Workaround / fix:** User pasted the PAT directly in chat. Agent used it as a transient env var.
- **Prevent next time:** Protocol now documents this — PAT goes in chat, never in the file. The `ai-engineering-protocol.md` Pre-Flight section warns about this explicitly.

---
## 2026-07-09 — Super Z / GLM-4.5 (Session 1)

- **Problem:** `pip install -e ".[dev]"` failed with `externally-managed-environment` error on system Python.
- **Cost:** One failed command before creating a venv.
- **Cause:** System Python 3.12 on the sandbox is locked down per PEP 668.
- **Workaround / fix:** Created a venv: `python3 -m venv .venv && source .venv/bin/activate`, then `pip install` succeeded.
- **Prevent next time:** Protocol now says "ALWAYS create a virtualenv first" in Step 4 and lists it as Common Pitfall #3.

---
## 2026-07-11 — Super Z / GLM-4.5 (Session 2)

- **Problem:** `git push` failed after the first commit because the remote URL had been stripped of the token (Step 2 strips it for security).
- **Cost:** One failed push before figuring out the re-add-token → push → strip-token dance.
- **Cause:** The clone command embeds the token in the remote URL, which persists in `.git/config` on disk. Step 2 correctly strips it, but that breaks subsequent pushes.
- **Workaround / fix:** Re-add the token to the remote URL before push, push, then strip it again: `git remote set-url origin "https://x-access-token:${GIT_TOKEN}@..." && git push && git remote set-url origin https://github.com/...`
- **Prevent next time:** Protocol Step 12 now documents this explicitly with the exact commands. Common Pitfall #19 added.

---
## 2026-07-11 — Super Z / GLM-4.5 (Session 2)

- **Problem:** The LocalMind clone from Session 1 was gone — the sandbox wipes `/home/z/my-project/` between sessions (only `/home/z/my-project/download/` persists).
- **Cost:** Had to re-clone the repo (30s) and re-create the backend venv (60s). No work lost since everything was pushed to remote.
- **Cause:** Cloud sandbox environment — no persistent storage between sessions by design.
- **Workaround / fix:** Re-cloned and re-installed. All prior work was safely on `origin/main`.
- **Prevent next time:** This is inherent to the sandbox. The `.context/` system (now bootstrapped) means the next session will at least have full context of what happened before, even though the local clone is gone. No protocol change needed — just be aware that cloud sandboxes start fresh each session.

---
## 2026-07-11 — Super Z / GLM-4.5 (Session 2)

- **Problem:** The SSRF redirect bypass fix initially had a test failure — `_is_url_safe()` tried to resolve `attacker.example.com` via real DNS, which failed (the domain doesn't exist).
- **Cost:** One failed test run before mocking `_is_url_safe` directly.
- **Cause:** The test mocked `httpx.AsyncClient` but not `_is_url_safe` — the real function still ran and hit real DNS.
- **Workaround / fix:** Mocked `_is_url_safe` with `patch("tools.web_fetch._is_url_safe", side_effect=_fake_is_url_safe)` so the test isolates the redirect-following logic without DNS dependency.
- **Prevent next time:** When testing functions that call external network resolution, mock the resolution function too — not just the HTTP client. Added a comment in the test file explaining this.

<!-- Session 3 (GitHub Copilot / DeepSeek V4 Flash Free) had 4 workflow-level
     inefficiencies that were moved to flaws/log.md on 2026-07-11. Those
     entries were about the protocol/.context/ system itself, not about
     LocalMind's code/environment. See .context/flaws/log.md for the full
     entries. Project-level inefficiencies from Session 3 (if any) would
     appear below. -->


---
## 2026-07-11 — Super Z / GLM-5.2 (Session 7)

- **Problem:** The `workflows/active.md` Protocol source field contains a `blob/` URL (`https://github.com/TisoneK/.context/blob/main/ai-engineering-protocol.md`), not a `raw/` URL. Fetching it via `curl https://raw.githubusercontent.com/...` (the raw equivalent) returned 404. Had to clone the entire `TisoneK/.context` package repo to get the 53KB protocol file.
- **Cost:** One failed `curl` (404) + one `git clone --depth 1` of the package repo (~2s, 156KB). Minor — the clone worked fine and also gave me the `roles/` and `examples/` directories for reference.
- **Cause:** The `blob/` URL is the HTML page on GitHub (rendered markdown with navigation chrome), not the raw file. The protocol's Step 3 says "fetch it from the URL in the `Protocol source` field" — an agent following literally would fetch HTML, not raw markdown. The `raw/` equivalent (`https://raw.githubusercontent.com/TisoneK/.context/main/ai-engineering-protocol.md`) should work but returned 404 this session (possibly a caching/timing issue, or the default branch isn't `main`).
- **Workaround / fix:** Cloned `TisoneK/.context` fresh: `git clone --depth 1 "https://x-access-token:${GIT_TOKEN}@github.com/TisoneK/.context.git" _context_pkg`. Read `ai-engineering-protocol.md` from there. Stripped token from `_context_pkg/.git/config` after clone.
- **Prevent next time:** Update `workflows/active.md` Protocol source field to give BOTH the `blob/` URL (for human browsing) AND the `raw/` URL (for agent fetch), OR instruct agents to clone the package repo as the reliable fallback. The protocol's Step 3 could say: "If the raw URL 404s, clone `TisoneK/.context` with `--depth 1` and read the file locally." Logged as a flaw too.

---
## 2026-07-11 — Super Z / GLM-5.2 (Session 7)

- **Problem:** `npm install` emitted `allow-scripts` warnings for `electron@33.4.11` (postinstall: `node install.js`) and `esbuild@0.25.12` (postinstall: `node install.js`). The scripts were not run — npm 11's `allow-scripts` feature blocks postinstall scripts by default for security.
- **Cost:** Zero — the frontend typecheck (`tsc -b`), lint (`eslint .`), and build (`vite build`) all work without these scripts. Electron's postinstall downloads the Electron binary (only needed for `npm run dev:electron` / `npm run build` of the desktop app). esbuild's postinstall downloads the platform-specific binary — but Vite brings its own esbuild binary, so this is redundant.
- **Cause:** npm 11 (installed on this sandbox) enables `allow-scripts` by default. Older npm versions ran postinstall scripts automatically.
- **Workaround / fix:** No workaround needed for review/lint/test work. If a future session needs to build the Electron app (`npm run build`), run `npm approve-scripts --allow-scripts-pending` first, or `npm approve-scripts electron esbuild` for just those two.
- **Prevent next time:** Documented in `system/environments.md` Quirks section. Future sessions doing Electron builds: approve the scripts first.

---
## 2026-07-27 — Super Z / GLM-5.2 (Session 31)

- **Problem:** The `docs/shell_tool_fix_analysis.md` doc was misleading on first read — it diagnoses the `re` conditional-import bug as the root cause of the user's "Tools execution failure" symptom, but that bug was already fixed in a prior session. I spent ~10 minutes verifying the shell tool was healthy before realizing the doc was stale and the actual remaining bug was the silent-failure FALLBACK PATH in the engine + agent loop.
- **Cost:** ~10 minutes of redundant code reading + a brief detour thinking I'd need to fix `shell.py` before realizing the tool was already healthy.
- **Cause:** The doc was written when the bug was live; it was never updated after the fix landed. Future agents reading it as authoritative would re-investigate the same already-fixed code.
- **Workaround / fix:** Verified the current state of `shell.py` directly (`import re` at line 38 — top of module; `SYSTEM = platform.system()` at line 54 — resolved once). Identified the real remaining bug (silent-failure fallback) by tracing the user's exact symptom through the code.
- **Prevent next time:** Backlogged: delete or rewrite `docs/shell_tool_fix_analysis.md` to reflect the current state. Either remove it (the analysis is historical) or convert it to a "historical record" section noting which items are fixed. A future session should pick this up.

---
## 2026-07-27 — Super Z / GLM-5.2 (Session 31)

- **Problem:** `AgentStep` dataclass requires `tool_input` and `observation` as positional args (no defaults), but the existing test pattern in `tests/core/test_empty_agent_fix.py` constructs it with positional args in some places and keyword args in others. When writing the new regression test, I used keyword-only args and missed `tool_input`/`observation` — got a `TypeError` on the first test run.
- **Cost:** One failed test run + one quick Edit to fix.
- **Cause:** `AgentStep`'s required fields aren't documented in the dataclass docstring; you have to read the definition or look at existing usage.
- **Workaround / fix:** Added the missing `tool_input=None, observation=None` kwargs to the test. Test passed on next run.
- **Prevent next time:** When constructing `AgentStep` in tests, always pass all required fields explicitly — don't rely on defaults that don't exist. Could be fixed at the source by giving `tool_input` and `observation` default values of `None`, but that's a behavior change for another session.

---
## 2026-07-27 — Super Z / GLM-5.2 (Session 31, addendum)

- **Problem:** I shipped a fallback message that guessed "free-tier model overload" as the cause of the "Tools execution failure" bug — WITHOUT testing against the real model first. The user correctly pushed back: "for a 4-step task, context overflow is not plausible." The "overload" diagnosis was a plausible-sounding but unverified self-diagnosis — same pattern as the earlier "tool output too large" message that turned out to be wrong.
- **Cost:** Two extra commits (f316904 + d09327c) and one extra round-trip with the user. The first fix (08d1934) was treating the symptom, not the cause. The revision (f316904) made the fallback more honest but was STILL treating the symptom. The actual root cause (two adapter bugs) wasn't found until the user provided an API key for real-model testing.
- **Cause:** I trusted my own plausible-sounding guess instead of testing it. The fallback message was written BEFORE any real-model testing. When the user pushed back, it took 10 minutes and 2 API calls to find the actual bug — should have done that FIRST.
- **Workaround / fix:** Real-model testing via the user's Zen API key found the root cause: (1) DeepSeek rejects messages ending with `tool` role → HTTP 400; (2) Phase 1 detection dropped tool_call deltas during long reasoning streams. Both fixed in commit d09327c.
- **Prevent next time:** When a fallback message GUESSES at a cause, treat the guess as a hypothesis to test, not a diagnosis to ship. If the user can provide an API key for the failing model, test against the real model BEFORE writing the fallback. The real-model test is almost always faster than the guess-revise-guess cycle. Logged as a flaw in `flaws/log.md` too — this is a protocol-level lesson, not just a project-level inefficiency.

---
## 2026-07-27 — Super Z / GLM-5.2 (Session 33)

- **Problem:** I shipped Session 32's fix (iteration limit + safety workflow + hit-limit-aware fallback) WITHOUT reading the flaw log first — and the flaw log explicitly contains the Session 31 lesson "don't ship without real-model testing." I repeated the exact same mistake: shipped code that broke the SSE stream because I didn't test against the real model.
- **Cost:** One broken session for the user (tools hung at "Running command") + one emergency fix session (Session 33). The user's trust in fix quality is eroded — "we have broken the tools again" is the third iteration of this pattern.
- **Cause:** I treated the `.context/` flaw/inefficiency logs as end-of-session bookkeeping instead of live diagnostic tools. The protocol requires reading them BEFORE starting work (to not re-hit logged traps) and appending AS I hit friction. I skipped the "read first" step.
- **Workaround / fix:** Found the regression by code inspection: Session 32's engine fallback called `_obs.drain()` (destructive) instead of `_obs.all()` (read-only), stealing events from the SSE bridge. Fixed in this session. But the deeper fix is process-level: I need to actually READ `flaws/log.md` and `inefficiencies/log.md` before starting any code changes.
- **Prevent next time:** BEFORE writing any code in a session, read `.context/memory/flaws/log.md` and `.context/memory/inefficiencies/log.md` IN FULL. Look for patterns that apply to the current task. If a prior session logged "don't do X without testing Y," and the current task involves X, test Y before shipping. This is the protocol's intended workflow — I've been skipping it.

---
## 2026-07-27 — Super Z / GLM-5.2 (Session 33 — ZenMux smoke test blocked)

- **Problem:** Tried to smoke-test the ZenMux provider (ADR-9) with the user's API key. The key authenticates (`GET /api/v1/models` returns 200 with 145 models) but every `POST /api/v1/chat/completions` returns 403 "You have no permission to access this resource." Tested 8 models across 6 providers (Grok 4.5, Claude Opus 5, Gemini 3.6 Flash, GPT-5.6 Luna, GLM-5.2, Ling 3.0 Flash, Kimi K3, MiniMax M3) — all 403. It's not a model-specific issue; it's an account-level access issue.
- **Cost:** ~10 minutes of testing before realizing the account can't make API calls at all. The smoke test caught this BEFORE any integration code was written — which is exactly what the smoke test is for. No code wasted.
- **Cause:** The user is on ZenMux's free plan ("5 Flows/5h, $0"), which explicitly states "Studio Chat only" and "No API Request access." The `/models` endpoint isn't gated (listing models is free), but `/chat/completions` requires a paid plan. The free Builder tier mentioned in the web research (~165 flows/month) apparently doesn't include API access either — it's Studio Chat only.
- **Workaround / fix:** None possible in code. The user needs to upgrade to a ZenMux plan that includes API access. Per ZenMux's pricing: Pro ($20/mo) adds latency/throughput insurance; Max ($100/mo) adds hallucination coverage; Ultra ($400/mo) includes SLA guarantees. Actual model usage is pay-as-you-go per-token against a topped-up balance, separate from the subscription. The user should check zenmux.ai for which plan includes API access — it may be that ANY paid plan unlocks it, or it may require a specific tier.
- **Prevent next time:** When integrating a new provider, check the plan requirements BEFORE requesting an API key. The web research for ADR-9 mentioned "free Builder subscription tier for personal development, capped at roughly 5 flows per 5 hours" — but didn't catch that this tier is Studio Chat only with no API access. ADR-9 has been updated to note: "the free plan does NOT include API access — a paid plan (Pro/Max/Ultra) is required for LocalMind integration." Future provider integrations should verify API access is available on the user's plan before starting the smoke test.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 36)

- **Problem:** The first baseline command used `python -m pytest`, but this macOS environment exposes only `python3`, and its system Python 3.9.6 is below the backend's declared Python >=3.10 requirement.
- **Cost:** One failed baseline invocation and a short setup detour.
- **Cause:** The local environment differs from the previously recorded Windows/cloud environments, and the generic command did not account for the backend's version constraint.
- **Workaround / fix:** Reused the installed uv-managed Python 3.12.13, created `backend/.venv`, installed `backend[dev]`, and ran validation through `backend/.venv/bin/python`.
- **Prevent next time:** Check `pyproject.toml`'s `requires-python` and available uv interpreters before running Python baseline commands; prefer the project-local venv path.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 37)

- **Problem:** The first reviewer report was returned as an internal reasoning fragment rather than a structured review summary, and the frontend has no test harness for its critical SSE parser.
- **Cost:** Review interpretation required an additional pass; the parser issue can currently be verified by code inspection but not locked with a frontend regression test.
- **Cause:** The project has strong backend coverage but no frontend tests, while the UI transport contract is split between a native stream parser and React state handlers.
- **Workaround / fix:** Used the backend API regression test for the shipped contract fix, validated the frontend with production build/lint, and recorded the parser follow-up separately instead of mixing it into the first fix.
- **Prevent next time:** Add a small frontend test harness around the SSE parser before changing more UI transport behavior.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 38)

- **Problem:** The frontend stream parser had no executable test boundary, so the final-buffer transport defect could only be identified by inspection during Session 37.
- **Cost:** The requested fix required introducing the first frontend test runner while repairing the parser.
- **Workaround / fix:** Added the project-local Vitest script/dependency, extracted a pure SSE parser, and locked the unterminated-event behavior with focused tests.
- **Prevent next time:** Keep transport helpers independently testable and add a public `streamChat()` integration fixture before changing additional UI stream behavior.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 50)

- **Problem:** The optional `agent-browser` CLI was not installed on this macOS checkout, so live BrowserAgent smoke testing could not run.
- **Cost:** No code rework; live validation was deferred after the mocked contract tests passed.
- **Cause:** Browser automation is an optional external CLI dependency and is not installed by default in this environment.
- **Workaround / fix:** Verified the documented command syntax through authoritative documentation and tested the wrapper at its subprocess boundary with 50 focused mocked tests.
- **Prevent next time:** Install `agent-browser` and Chromium before a session that requires live browser verification; keep mocked tests as the deterministic regression layer.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 52)

- **Problem:** The kickoff backend baseline is not fully green: one existing todo-plan assertion expects the older first-step label, while the current engine emits `Understand: ...`. Ruff also reports three non-E501 findings among the known line-length backlog.
- **Cost:** No implementation delay; the issue was documented rather than changed during a context-only kickoff.
- **Cause:** The test and current plan wording drifted across prior feature work, and safe lint cleanup was not folded into the related commits.
- **Workaround / fix:** Recorded the exact failing test and Ruff findings in the Session 52 review and environment handoff. No product changes were made.
- **Prevent next time:** Reconcile the todo-plan UI/test contract and clean the three non-E501 Ruff findings in a dedicated safe-fix session before starting the capability-family implementation.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 53)

- **Problem:** No new implementation friction. The existing backend baseline still contains the known todo-plan assertion drift, so the full suite is not completely green.
- **Cost:** No rework; the catalog was validated independently and the unrelated failure was preserved rather than changed opportunistically.
- **Cause:** The test expects older wording than the current engine plan output.
- **Workaround / fix:** Recorded the failure separately and kept the new capability catalog behavior isolated from todo-plan semantics.
- **Prevent next time:** Reconcile the todo-plan test/UI contract in a dedicated safe-fix session before expanding runtime capability discovery.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 54)

- **Problem:** The first observation implementation used a frozen outer dataclass while exposing mutable nested workspace/event objects.
- **Cost:** One review/fix cycle; no shipped defect because the issue was caught before commit.
- **Cause:** Top-level dataclass freezing was initially treated as sufficient snapshot immutability.
- **Workaround / fix:** Added private owned copies plus defensive-copy accessors and regression tests for source and accessor mutations.
- **Prevent next time:** Treat nested compatibility objects as mutable unless the ownership boundary is explicit; test both producer-side and consumer-side mutation.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 55)

- **Problem:** A final runtime snapshot initially read only the pending event queue, so events already flushed by the SSE bridge would be missing.
- **Cost:** One review/fix cycle; no shipped defect because the gap was caught before commit.
- **Cause:** The existing collector intentionally makes `drain()` destructive, and the first integration reused `all()` without modeling full request history separately.
- **Workaround / fix:** Added `ObsCollector.history()` while preserving `all()`/`drain()` semantics; snapshots now capture full request history before the final drain.
- **Prevent next time:** Separate pending-queue semantics from request-history semantics whenever a stream has multiple consumers.

---
## 2026-07-31 — Buffy / openai/gpt-5.6-luna (Session 57)

- **Problem:** The first frontend observation mapper trusted the typed API response at runtime; malformed nested fields could have crashed the Observe panel.
- **Cost:** One review/fix cycle and two focused regression cases; no shipped defect because the issue was caught before commit.
- **Cause:** TypeScript interfaces describe expected payloads but do not validate JSON received over the network.
- **Workaround / fix:** Added a defensive client-boundary mapper for strings, numbers, arrays, events, and build metadata, plus legacy-null and malformed-payload Vitest coverage.
- **Prevent next time:** Treat every API response as untrusted at the client boundary and add malformed-payload coverage whenever a new nested response shape is introduced.

---
## 2026-08-01 — Buffy / openai/gpt-5.6-luna (Session 63)

- **Problem:** The real-time Observe metrics fix was validated but left uncommitted while the prior session had already been reported complete.
- **Cost:** One corrective closeout pass and an additional product/context commit cycle.
- **Cause:** The implementation flow stopped after review and testing instead of running the repository exit checklist through commit, push, context update, and clean-tree verification.
- **Workaround / fix:** Committed the product surface as `8f253bf`, pushed it, then prepared a separate context closeout with review, session, summary, environment/model, feature, and friction updates.
- **Prevent next time:** Treat validation as an intermediate gate only; always run the two-surface exit checklist before reporting completion, including `git status --short --branch` and remote synchronization.

---
## 2026-08-02 — Super Z / GLM-5.2 (Session 65)

- **Problem:** I produced the entire Codebuff research package (~2,300 lines across 6 files) at `/home/z/my-project/download/codebuff-research/` BEFORE loading the protocol edition (`.context/core/rules/ai-engineering-protocol.md`). The protocol requires reports in `.context/memory/reviews/` and session notes in `.context/memory/sessions/`. I had to move all the content into the repo's `.context/memory/` structure and delete the bogus `kickoff.md` I had created. The user caught the kickoff.md mistake; the rest of the package was salvageable (comparison.md, recommendations.md, codebuff-deep-profile.md were good content, just in the wrong location).
- **Cost:** ~20 minutes of wasted work creating the `/download/` package + ~10 minutes moving content into the repo's `.context/memory/` + one user round-trip ("was kickoff.md read-only or create???"). The research itself was not wasted — only the packaging location was wrong.
- **Cause:** I read `.context/kickoff.md` (Step 2 of the kickoff) but skipped Step 3 ("Load the protocol" — `.context/core/rules/ai-engineering-protocol.md`). Without the protocol loaded, I didn't know that reports belong in `.context/memory/reviews/YYYY-MM-DD-review.md` (per Step 13 of the protocol) or that session notes belong in `.context/memory/sessions/YYYY-MM-DD-N/notes.md` (per Step 17). I defaulted to writing to `/home/z/my-project/download/` (the sandbox's user-downloadable directory) because that's where my system prompt says deliverables go — but the `.context/` protocol overrides that for `.context/`-managed repos.
- **Workaround / fix:** Deleted the bogus `kickoff.md`. Loaded the protocol edition. Moved the research content into the repo: review report → `.context/memory/reviews/2026-08-02-review-1.md`, full research detail → `.context/memory/sessions/2026-08-02-1/` (notes.md + codebuff-deep-profile.md + comparison.md + recommendations.md), backlog items → `.context/memory/tasks/backlog.md`. Committed and pushed per the protocol's two-surface rule (`docs(review):` for the report, `chore(context):` for the memory updates).
- **Prevent next time:** ALWAYS load the protocol edition (Step 3 of kickoff) BEFORE producing any deliverable. The protocol tells you WHERE outputs go. Skipping Step 3 because "the task seems small" or "I know what a report looks like" is the exact anti-pattern the protocol warns about (Step 4: "Don't skip Phase 1 because the task seems small"). For `.context/`-managed repos, the protocol's output locations override the sandbox's `/home/z/my-project/download/` default. Also logged as a flaw — the kickoff template could be clearer that it's READ-ONLY.

---
## 2026-08-02 — Super Z / GLM-5.2 (Session 65, second inefficiency)

- **Problem:** I stored the GitHub PAT and ZEN_API key in `/home/z/my-project/.secrets.env` (a single file, `.env` extension, outside the `.context/` structure) instead of `.context/memory/secrets/<slug>` (one secret per file, per the secrets README contract). The user caught it: "You also created your own secrets instead of reading how to use it in .context."
- **Cost:** ~5 minutes to create the proper secret files (`github-pat` and `zen-api` in `.context/memory/secrets/`), delete the improper `.secrets.env`, verify gitignore + chmod 600, and log the flaw. Minor in time, but it's a second protocol violation in the same session (after the kickoff.md mistake) — both rooted in the same cause: skipping Step 3 (load the protocol edition).
- **Cause:** I read `.context/memory/secrets/README.md` during Step 2 (the memory sweep) but treated it as passive documentation rather than a binding contract. When the user provided the PAT and ZEN_API in chat, I defaulted to the sandbox convention (`.env` file at workspace root) instead of the project convention (`.context/memory/secrets/<slug>`). The connection between "secrets/README.md describes a contract" and "I must use this contract when I receive credentials" wasn't made because I hadn't loaded the protocol edition (Step 3) that tells agents to store credentials at `.context/memory/secrets/github-pat` per `ai-engineering-protocol.md` Step 1.
- **Workaround / fix:** Created `.context/memory/secrets/github-pat` (line 1 = PAT, lines 2+ = scope/added/rotate notes, chmod 600) and `.context/memory/secrets/zen-api` (same format). Verified both are gitignored via `git check-ignore`. Deleted `/home/z/my-project/.secrets.env` and the `/home/z/my-project/.gitignore` I had created to exclude it. The proper secret files are now in place for any future session on this sandbox (though cloud sandboxes wipe between sessions, so they'll need to be recreated next time — the user will need to paste the PAT in chat again per the protocol).
- **Prevent next time:** When you receive a credential in chat (PAT, API key, etc.), the storage location is `.context/memory/secrets/<slug>` — one file per secret, no extension, line 1 = value, lines 2+ = notes, chmod 600. Read `.context/memory/secrets/README.md` if you need a refresher on the format. Never create a `.env`, `.secrets`, or `.secrets.env` file outside `.context/`. This is documented in `ai-engineering-protocol.md` Step 1 and `.context/memory/secrets/README.md` — both of which I had read but didn't apply because I hadn't loaded the protocol as a binding instruction set (Step 3).
---
## 2026-08-03 — Buffy / openai/gpt-5.6-luna (Session 66)
- **Problem:** The first incremental code-execution reader returned strings, but the caller still decoded them as bytes; the focused tests caught the regression immediately. The first shell integration test also used an overcomplicated subprocess mock and failed to model process polling correctly.
- **Cost:** Two short validation/fix cycles.
- **Cause:** The reader's return contract changed during the bounded-capture refactor, and the test initially mocked implementation details instead of exercising a real command.
- **Workaround / fix:** Kept decoding inside the stream reader, treated collected output as strings, simplified shell coverage to a real short-lived command, and added compile/Ruff/full-suite validation before commit.
- **Prevent next time:** When changing stream ownership, define and test the reader return type before wiring callers; prefer real short-lived subprocess tests for capture behavior and reserve mocks for failure-specific cases.

---
## 2026-08-09 — Buffy / deepseek-v4-flash (Session 67)

- **Problem:** `docs/PERFORMANCE_BOTTLENECK_REPORT.md` and `docs/PERFORMANCE_IMPLEMENTATION_PLAN.md` (2026-05-15) were the first hit when verifying the reviewer's latency claim, and both are stale in three misleading ways: they reference dead file paths (`core/engine.py` — now `core/engine/_pipeline.py`), claim `DISPATCHER_HIGH_CONFIDENCE_SKIP=0.7` (now 0.6), and recommend reducing `MAX_ITERATIONS` 8→5 — which directly contradicts the Session 32 standing contract ("Do NOT lower below 8"). I had to verify the current pipeline code directly instead of trusting the docs, and had to be careful not to carry the docs' superseded recommendation forward.
- **Cost:** ~15 minutes of cross-checking code vs docs; one real risk avoided (I nearly treated "reduce MAX_ITERATIONS to 5" as a live recommendation before catching the Session 32 contract).
- **Cause:** The docs were written 2026-05-15 (pre-Sessions 21-32) and never updated after the trivial-input short-circuit (Session 21), the parallel memory retrieval, the skip-logic changes, and the Session 32 MAX_ITERATIONS contract.
- **Workaround / fix:** Verified the live behavior in `_pipeline.py` / `thinking_dispatcher.py` / `trivial_input.py` directly. Filed B-2026-08-09-7 to rewrite/annotate both docs as historical records.
- **Prevent next time:** When a doc references a `core/engine.py` path or pre-2026-07 constants, check `.context/memory/plans/decisions.md` and recent session entries for superseding contracts before following any recommendation in it. Also found while reviewing: `THINKING_DISPATCH_TIMEOUT_SECS=12.0` (constants.py) vs `DISPATCHER_TIMEOUT_SECS=30.0` (thinking_dispatcher.py) disagree — backlogged as B-2026-08-09-11.

---
## 2026-08-09 — Buffy / deepseek-v4-flash (Session 68)

- **Problem:** When refactoring `trivial_response` to share a helper with the new `conversational_response`, I first wrote the helper as a plain `def` containing `async for` (SyntaxError: 'async for' outside async function) and then as an `async def` that `return`ed the inner async generator instead of iterating it — the latter makes the public functions coroutines, breaking `async for chunk in conversational_response(...)` at runtime.
- **Cost:** One failed test run (collection SyntaxError) + one runtime-shape fix, plus a third edit to correct the `async def` return-vs-iterate mistake. ~5 minutes.
- **Cause:** Two async-generator pitfalls hit in sequence: forgetting `async` on a generator helper, then assuming `return <async generator>` from an `async def` keeps it an async iterator (it doesn't — no `yield` in the body makes it a coroutine function).
- **Workaround / fix:** Made the helper `async def` with `yield` inside, and both public wrappers iterate it (`async for chunk in helper(...): yield chunk`).
- **Prevent next time:** When a public `async def` must be an async iterator, the body must contain `yield` (or explicitly iterate a child generator) — `return <agen>` silently converts it into a coroutine function. Add a quick test that does `[c async for c in fn(...)]` for every new streaming helper.

---

- **Session:** 69 (2026-08-09)
- **Symptom:** `py_compile` failed with `IndentationError: unexpected indent (_pipeline.py, line ~2299)` right after wiring `_StageClock` into the graph-execution branch.
- **Cost:** One failed compile + one corrective `str_replace` + recompile. ~3 minutes.
- **Cause:** The `str_replace` oldString for the graph block was written with 12-space leading indentation while the target block sits inside an `else:` at 16 spaces — the edit applied but de-indented the block, breaking Python's block structure.
- **Workaround / fix:** Re-anchored the replacement on the block's exact surrounding lines (`self._metrics.start_request()` … `executed_graph = await execute_graph(`) preserving 16-space indent; verified with `py_compile`.
- **Prevent next time:** Before inserting lines into an `if/else` block, copy the exact indentation of the anchor lines (16 spaces inside `else:`, not the 12 of the parent) and always run `py_compile` on the edited module immediately after a multi-line edit — a 1-second check that catches structural breaks before tests.

---
## 2026-08-09 — Buffy / deepseek-v4-flash (Session 70)

- **Problem:** (1) Two `spawn_agents` calls for `code-searcher` failed with "Invalid params: expected array" — the `searchQueries` array was omitted from params, so each failure cost a wasted round-trip. (2) The B-8 `toolsUsed` staleness fix in `useLocalMind.ts` took real verification effort to confirm it is defensive-only: SSE `turn_complete` obs events never carry `tools_used` (only `_store_observation` does), so the streaming panel's tools are driven by `tool_call` events + the send()-time reset; the `!== undefined` fix is correct semantics but changes nothing observable today.
- **Cost:** 2 failed spawns (~1 min) + ~5 min verifying backend obs-event key semantics across 5 `turn_complete` emit sites.
- **Cause:** (1) Tool schema slipped while batching parallel spawns. (2) The B-8 backlog line pointed at `useLocalMind.ts` ~L605 without noting that the SSE obs payload omits `tools_used`, so the "stale tools" symptom is not reachable via the streaming path.
- **Workaround / fix:** (1) Re-issued spawns with explicit `searchQueries`. (2) Kept the frontend fix (harmless, future-proof) and recorded the backend reality here + in sessions.md.
- **Prevent next time:** Always include `params.searchQueries` when spawning code-searcher. Before implementing a frontend fix that reads an obs-event field, grep the backend `_obs.emit(...)` call sites for that exact kwarg — if it only appears in `_store_observation`, the streaming path never sees it.

---
## 2026-08-09 — Buffy / deepseek-v4-flash (Session 71)

- **Problem:** The trivial/conversational short-circuit cleanup blocks called `self._store.add_message(session_id, "user", message)` — but `SessionStore` has NO `add_message` method. The call raised `AttributeError` inside the best-effort try, so `trivial_short_circuit_done` never actually emitted and the user message was never persisted on short-circuit turns. Pre-existing silent failure (the try swallowed it since the trivial path was introduced).
- **Cost:** One failed test run (new turn_complete assertions got 0 events) + a debug script to pinpoint the exception (~10 min).
- **Cause:** The trivial path used a nonexistent `SessionStore.add_message` API instead of the persistence mixin's `_persist_user_message(session_id, message)` used by every other completion path.
- **Workaround / fix:** Switched both short-circuit paths to `self._persist_user_message`. Also restructured so `turn_complete`/`_store_observation` run in their OWN best-effort try — observability must never depend on persistence succeeding.
- **Prevent next time:** When adding a test that asserts an obs event fires, first confirm nothing earlier in the same try block can raise — a swallowed exception in a best-effort try silently skips every following emit. Grep for the correct persistence API (`_persist_*` mixin) rather than assuming `SessionStore` has a method with a guessed name.

---
## 2026-08-09 — Buffy / deepseek-v4-flash (Session 72)

- **Problem:** One `str_replace` in `client.test.ts` used an oldString that was a PREFIX of an existing test's body (3 lines of a larger assertion) instead of a unique whole-block anchor. The replacement inserted a copy of that block's ending + the new describe block, and the original continuation was left orphaned — the file temporarily had a duplicated `observation` matcher and a stray dangling block.
- **Cost:** One inspection + one corrective `str_replace` + re-run (~3 min).
- **Cause:** The oldString matched the first 3 lines of the last test's `toMatchObject` call — not unique/self-contained — so the edit duplicated instead of replacing cleanly.
- **Workaround / fix:** Re-read the file, identified the orphaned duplicate at EOF, and removed exactly that block with a targeted replacement.
- **Prevent next time:** When appending a new describe/test block to an existing test file, anchor the insertion on a UNIQUE, self-contained boundary (e.g. the final `});` of the file, or a complete statement) — never on a partial line sequence that could be a prefix of larger content. After any multi-line edit to a test file, run the test suite immediately (a SyntaxError or duplicate-assertion failure surfaces within seconds).

---
## 2026-08-12 — Buffy / deepseek-v4-flash (Session 152)
- **Problem:** Four `code-searcher` spawns failed with `ENOTDIR: not a directory, posix_spawn '/Users/bao/.config/manicode/rg'` when the `cwd` param pointed at a FILE (`loop.py`) instead of a directory.
- **Cost:** ~1 min (one wasted round-trip).
- **Cause:** `searchQueries[].cwd` must be a directory; passing a file path made ripgrep's spawn target resolve through the config shim and fail.
- **Workaround / fix:** Re-issued with `cwd` omitted and file-targeted searches scoped via `-g 'loop.py'` / `-g '_pipeline.py'` glob flags.
- **Prevent next time:** Never pass a file path as `cwd` — scope single-file searches with `-g '<filename>'` flags.

---
## 2026-08-12 — Buffy / deepseek-v4-flash (Session 153)
- **Problem:** Restarting the dev backend to reload code left the app DOWN for several minutes. Two `nohup ... &` restarts from agent shells died the moment the spawn session ended, and two `launchctl submit` retries failed with server.py's `[startup] Port ... already in use` exit-42 even though nothing was LISTENing.
- **Cost:** ~6 min of restart churn + probes.
- **Cause:** (1) Processes backgrounded from an agent shell are killed when the harness reaps the shell's process group — `nohup` only guards SIGHUP, not a group kill; (2) `backend/server.py:is_port_in_use()` binds WITHOUT `SO_REUSEADDR`, so a graceful shutdown's lingering TIME_WAIT sockets (~15s on macOS) make the pre-check fail with exit 42; (3) server.py's graceful shutdown takes ~4s, so a kill+immediate-relaunch hits the race.
- **Workaround / fix:** Relaunch via `launchctl submit -l com.localmind.backend -- <venv-python> /abs/path/backend/server.py` (a launchd job survives agent sessions), AFTER waiting for `lsof -i :8000` to show ZERO sockets. Electron's normal flow also restores the backend (main.js spawns server.py when its health check fails).
- **Prevent next time:** To reload backend code on this machine: (1) `launchctl remove com.localmind.backend`, (2) poll until `lsof -i :8000` is empty, (3) `launchctl submit -l com.localmind.backend ...`, (4) poll /api/health. Never rely on nohup'd processes from an agent shell for anything that must outlive the session.

---

## 2026-08-13 — Super Z / GLM-5.2 (Session 176)

- **Problem:** `uv sync` in `backend/` fails because `pyproject.toml`
  specifies `readme = "../README.md"` and hatchling refuses paths outside
  the project directory ("Readme path must be within the project
  directory").
- **Cost:** ~3 min of trial-and-error + reading the uv error.
- **Cause:** Hatchling's build backend enforces project-directory
  containment; the LocalMind backend `pyproject.toml` is a sub-package of
  the root repo and points at `../README.md`. uv's `sync` invokes the
  build backend to compute metadata, hitting the refusal.
- **Workaround / fix:** Don't use `uv sync`. Use the verified pattern:
  `uv venv backend/.venv --python 3.12` then `uv pip install --python
  backend/.venv/bin/python -e 'backend[dev]'` with a temporarily-patched
  `pyproject.toml` (sed the readme path to a local copy, install, restore
  the original). One-liner documented in
  `system/environments.md` Session 176 entry. The pre-existing venv at
  `backend/.venv` already has all deps installed from prior sessions, so
  fresh-install is rarely needed in practice.
- **Prevent next time:** Read `system/environments.md` BEFORE attempting
  `uv sync` — Session 52 already recorded the working pattern. Don't
  rediscover.

---

## 2026-08-13 — Super Z / GLM-5.2 (Session 184)

- **Problem:** The Bash tool times out when running long Python scripts (>2 min). The smoke test script (8 prompts × ~30-60s each = 4-8 min) exceeded the 2-minute default timeout and the 10-minute max timeout. The tool returned "context deadline exceeded" repeatedly.
- **Cost:** ~3 failed attempts before identifying the fix: split the smoke into per-prompt scripts that each complete within the 2-minute default timeout.
- **Cause:** Each Bash tool call has a max timeout of 600000ms (10 min). Long-running scripts that boot backend + frontend + run 8 prompts + capture screenshots exceed this. The bash tool itself also seems to have a shorter internal timeout (~90s observed) that kills the call even when the timeout parameter is set higher.
- **Workaround / fix:** 
  1. Boot backend + frontend ONCE via `setsid`-detached `subprocess.Popen(start_new_session=True)` — they survive across bash calls.
  2. Run each prompt in a SEPARATE bash call (each takes ~30-60s, well within the timeout).
  3. Use a separate script to generate the summary from the saved transcripts.
  The scripts are at `/home/z/my-project/scripts/smoke_boot.py` (boot/shutdown/run-by-index) and `/home/z/my-project/scripts/smoke_summary.py` (parse + summarize).
- **Prevent next time:** When a Python script takes >2 min to run, split it into: (a) a detached boot step, (b) per-item execution steps, (c) a summary step. Never run a monolithic 5+ minute script through the Bash tool — it will time out. Use `start_new_session=True` (not `preexec_fn=os.setsid` — they conflict and cause "Exception in preexec_fn").

---

## 2026-08-13 — Super Z / GLM-5.2 (Session 184, second inefficiency)

- **Problem:** Port 8000 stays in TIME_WAIT after backend shutdown (~15s on this Linux sandbox), causing the next boot to fail with "Port 127.0.0.1:8000 is already in use" even though no process is LISTENing.
- **Cost:** ~3 min of restart churn across multiple boot attempts.
- **Cause:** Same as Session 153's documented issue (macOS launchctl pattern). On Linux, the fix is `fuser -k -9 8000/tcp` + wait 5s for TIME_WAIT to clear, THEN re-launch.
- **Workaround / fix:** Before booting the backend: `fuser -k -9 8000/tcp 2>/dev/null; sleep 5`. The `smoke_boot.py shutdown` command handles this automatically via `os.killpg(SIGTERM)`.
- **Prevent next time:** Add a `wait_for_port_clear(port, timeout=15)` helper to the smoke script that polls `ss -tlnp | grep :{port}` until empty before attempting to boot.

- 2026-08-13 (Session 185, post-merge): ADR-19 level-aware memory retrieval keys off the dispatcher plan task_type, but ADR-22 demoted the dispatcher to a hint because free-tier misclassifies (3/8 prompts in the 184 smoke). A misclassified task retrieves the wrong memory levels. Fix direction: re-key the level-aware re-retrieval on the task_type the agent settles on during planning. Also: session numbers 176-179 are now ambiguous (two parallel branches used them) - cite commit SHAs when referencing sessions.

- 2026-08-13 (Session 186): RESOLVED the ADR-19 x ADR-22 composition finding above. Level-aware memory retrieval + decision-ledger recall + decision sink + summarizer policy now key off `_settled_task_type = resolve_task_type(hint, intent)` — the task type the agent settles on during planning (intent is the settled routing for AGENT turns). Explicit canonical hints still win except a 'chat' hint on a non-CHAT routing (definitionally a misclassification). Full backend 1635 green.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 197)

- **Problem:** The first `python --version` probe failed because this macOS
  shell has no `python` alias; an initial compound probe stopped before the
  remaining runtime output was shown. Two `code_search` calls also failed when
  a compound/file `cwd` was supplied, and one later call hit the vendored-rg
  executable path error.
- **Cost:** Minor diagnostic delay; no product impact.
- **Cause:** macOS PATH and project search-tool invocation constraints.
- **Workaround / fix:** Used `python3` for discovery, the project
  `backend/.venv/bin/python` for all checks, and single-directory `code_search`
  calls for source navigation.
- **Prevent next time:** Start runtime probes with the recorded venv path and
  keep each code search scoped to one directory.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 198)

- **Problem:** The focused freshness test command returned non-zero several times while the new test fixture and import ordering were being adjusted; the historical progress output did not retain the failure details.
- **Cost:** A few short reruns and inspections before the final focused suite passed.
- **Cause:** Incremental test edits were validated before the fixture had reached its final contract.
- **Workaround / fix:** Re-read the current test and implementation, reran the focused suite from the final working tree, then ran the full CI gate.
- **Prevent next time:** Capture the full focused-test output on the first failure instead of relying on a progress summary, and rerun the focused suite after the final edit before starting the full gate.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 199)

- **Problem:** The initial delegation trace had to distinguish the internal
  parent `ToolResult` path from the separate observability/SSE path; treating
  all child output as one channel would have either leaked raw results or
  hidden useful progress.
- **Cost:** One clarification turn and a targeted boundary review.
- **Workaround / fix:** Kept complete child events in the child collector,
  forwarded only progress metadata through `ChildObsProxy`, and added a second
  SSE presentation filter for child-tagged/delegation events.
- **Prevent next time:** When debugging agent interception, trace internal
  tool messages and user-facing observability events separately before changing
  the parent loop.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 200)

- **Problem:** Several scoped `code_search` calls failed because the vendored
  ripgrep executable path was unavailable, and combined reads of large context
  files were truncated.
- **Cost:** Minor navigation delay during the legacy-path trace.
- **Cause:** The local Codebuff search wrapper's configured rg path was stale;
  the repository's session logs and pipeline files are large.
- **Workaround / fix:** Used one-directory searches where available, direct
  bounded file windows, and read-only shell inspection (`grep`, `tail`, `sed`)
  for large memory files. No product behavior depended on the failed searches.
- **Prevent next time:** Start with bounded file windows and fall back quickly
  to direct read-only shell inspection when the search wrapper reports a missing
  vendored rg binary.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 201)

- **Problem:** The first replacement slice temporarily treated the reference
  name “Buffy” as a LocalMind product agent, then had to be reverted after the
  user clarified that Buffy/Codebuff/Freebuff were research references only.
- **Cost:** A mistaken uncommitted implementation slice and several inspections;
  no incorrect product code was retained.
- **Cause:** The reference research used “Buffy” as the orchestrator identity,
  and the implementation note was read as a naming requirement instead of an
  architectural behavior reference.
- **Workaround / fix:** Removed the accidental `agents/buffy/` tree completely,
  reread ADR-8 and the LocalMind feature records, and implemented the runtime
  under the neutral LocalMind-native `ParentAgent` name.
- **Prevent next time:** Treat names in prior-art research as examples unless
  the repository ADR explicitly requires them; confirm product identity from
  the active architecture records before creating new modules.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 203)

- **Problem:** The first product commit command failed because shell heredoc
  quoting interacted poorly with an apostrophe in the commit body.
- **Cost:** One retry; no repository changes were lost.
- **Cause:** Embedded shell quoting in a generated commit command.
- **Workaround / fix:** Removed the apostrophe from the message and reran the
  commit command successfully.
- **Prevent next time:** Keep heredoc commit messages free of shell-sensitive
  punctuation or use a quoted message without nested apostrophes.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 204)

- **Problem:** The current-time regression needed to be fixed in a large
  parent-loop module with multiple single-/multi-tool seams, and the first
  focused test assertion used `August 1` as a substring that also matched the
  valid `August 14` result.
- **Cost:** One focused test failure and one small test correction; no product
  behavior was lost.
- **Cause:** The assertion checked a non-boundaried date prefix.
- **Workaround / fix:** Changed the assertion to reject the complete invalid
  date `August 1, 2026`; then reran focused, full, and CI validation.
- **Prevent next time:** Use complete date tokens or regex boundaries when
  asserting that one calendar date is absent from another date's text.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 205)

- **Problem:** The first live-SSE implementation added a shielded pending task,
  but tool observations still remained queued until the next engine chunk.
- **Cost:** One implementation pass and an additional selective-drain helper
  were needed before the transport actually exposed tool results during a slow
  operation.
- **Cause:** Connection keepalive and user-visible progress were treated as the
  same concern; a comment heartbeat does not flush application observations.
- **Workaround / fix:** Added `ObsCollector.drain_matching()` and a heartbeat
  bridge for tool/terminal events, leaving unrelated observations queued.
- **Prevent next time:** When adding streaming heartbeats, test event ordering
  while the producer is deliberately pending; an HTTP keepalive-only test is
  insufficient.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 206)

- **Problem:** Restoring the trivial-input runtime call initially caused a
  circular import during test collection.
- **Cost:** One failed focused test invocation and a small import adjustment.
- **Cause:** `trivial_input` imports `core.engine._helpers`, while the
  `core.engine` package initializer imports `AgentRuntime`.
- **Workaround / fix:** Loaded the trivial/conversational helpers lazily inside
  `AgentRuntime._process_unlocked()` at the boundary where they are needed.
- **Prevent next time:** Treat helpers imported by `core.engine` submodules as
  lazy-import candidates when wiring them into the runtime module.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 207)

- **Problem:** The first workflow-progress test fixture used a shortened
  `STEPS:` format that LocalMind's parser intentionally rejects, so the test
  could not observe the parsed plan summary.
- **Cost:** One focused test failure and one fixture correction.
- **Cause:** The fixture omitted the planner contract's `UNDERSTANDING`/
  `ARGS_PRECHECK` framing and used filler step labels that the parser filters.
- **Workaround / fix:** Made the fixture match the real structured planner
  format and use concrete tool-bearing steps; the focused workflow tests then
  passed.
- **Prevent next time:** Reuse the actual planner output contract when testing
  plan parsing, including concrete step wording that survives filler filtering.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 208)

- **Problem:** The first frontend validation command ran from the repository root,
  where no `package.json` or root `tsconfig.json` exists; both npm test and
  TypeScript failed before running project checks.
- **Cost:** One parallel validation pass and a short rerun.
- **Cause:** The frontend package is under `frontend/`, while backend commands use
  the repository root with the project-local backend venv.
- **Workaround / fix:** Read `frontend/package.json` and reran `npm test -- --run`
  plus `npx tsc -b && npm run lint && npm run build` with `cwd=frontend`; all
  passed.
- **Prevent next time:** Use the recorded package boundary: backend checks from
  the repo root with `backend/.venv/bin/python`; frontend npm checks from
  `frontend/`.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 209)

- **Problem:** The user-facing transcript still felt like `prompt → tool →
  answer`, despite existing plan/status/tool UI. The live web-search path ended
  the parent turn before the parent could decide what to do with search evidence.
- **Cost:** One architecture trace and one focused regression slice; no frontend
  rewrite was needed.
- **Cause:** Three duplicated web-search branches in AgentLoop called the legacy
  synthesis helper and returned terminal chunks directly. The normal tool-message
  continuation path was bypassed only for web search.
- **Workaround / fix:** Removed the terminal shortcut from native, MiniMax/text,
  and late-intercepted calls. Search results now follow the ordinary tool-message
  path and the parent makes the next decision. Added a second-decision regression.
- **Prevent next time:** When adding a special tool handler, test that successful
  output re-enters the parent loop and that only a verified parent response emits
  `done`; never infer completion from tool success alone.

---
## 2026-08-14 — Claude Code / claude-opus-4-8 (Session 210)

- **Problem:** Wanted a visual screenshot of the redesigned Actions
  timeline. Built a throwaway vite dev harness (`harness.html` + a small
  `src/harness.tsx` mounting the real component with mock `ToolCall`
  data). The harness threw React "Invalid hook call / Cannot read
  properties of null (reading 'useState')" — a dev-server dual-React
  resolution quirk for an extra entry point that pulls in framer-motion
  hooks — and separately the in-app browser pane wouldn't composite
  frames ("pane is not displayed"), so no screenshot was possible.
- **Cost:** ~15 min on the harness + browser round-trips, abandoned.
- **Cause:** (1) The in-app Browser blocks `navigate` to `localhost`;
  `preview_start {url}` opens it but the pane stayed hidden this session.
  (2) A second vite entry that imports framer-motion can resolve a
  duplicate React in dev optimize-deps, breaking hooks — the app's own
  build/tests are fine (production `vite build` + jsdom vitest pass).
- **Workaround / fix:** Dropped the harness; verified with a durable
  `ToolSteps.test.tsx` (9 jsdom render cases) + `vite build`. This is
  better anyway — permanent coverage instead of a throwaway screenshot.
- **Prevent next time:** For a pure component visual check, prefer a
  jsdom render test over a live harness. If a real screenshot is needed,
  drive the actual app (single React graph) rather than a bespoke second
  vite entry, and confirm the browser pane is displayed before relying on
  `computer{screenshot}`. Live-app visual verification still needs a
  provider credential to produce a real streaming turn.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 220)

- **Problem:** The Claude Code handoff ended during closeout while the full
  suite was still running, leaving ADR-32's loop-level remainder and memory
  records unfinished.
- **Cost:** No product rework was needed beyond the handoff's in-progress
  changes; one closeout pass was required to reconcile the adapter and loop
  stages and record the completed suite.
- **Cause:** The session exhausted its token budget after product validation
  but before the separate review/backlog/session-memory closeout.
- **Workaround / fix:** Resumed from the committed handoff, completed the
  loop/runtime fail-fast propagation, waited for the full suite result, then
  recorded the review, feature manifest, backlog closure, and append-only logs
  as separate context work.
- **Prevent next time:** Treat closeout as a required phase with its own
  bounded checklist; do not mark an ADR complete until the full suite result,
  review, backlog, feature memory, session log, and clean-tree verification are
  all recorded.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 221)

- **Problem:** The screenshot mixed two symptoms—an addressed greeting taking
  a provider round-trip and provider errors appearing after a wait—so the
  first diagnosis needed a source trace rather than assuming the parent loop
  was broken.
- **Cost:** One focused trace across `AgentRuntime`, `trivial_input`,
  `AgentLoop`, the adapter, and the SSE boundary; no broad rework.
- **Cause:** `Hey LM` was not covered by the whole-message greeting regex.
  The provider-error cards were a separate real-call failure path, already
  covered by ADR-32's terminal propagation tests.
- **Workaround / fix:** Added addressed-greeting matching and runtime tests
  for zero adapter acquisition/parent entry; documented the distinction
  between direct-chat provider latency and parent-loop execution.
- **Prevent next time:** Classify the transcript by execution mode first—
  deterministic social, direct conversational, or substantive parent—then
  inspect provider error timing within that mode instead of treating every
  assistant turn as one loop shape.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 222)

- **Problem:** Session 221 fixed one addressed greeting with another prompt-shaped
  exception, but that left the architectural complaint unresolved: the model was
  still not the owner of the initial meaning/response decision.
- **Cost:** One additional architecture trace and a deliberate rewrite of the
  previous session's runtime-routing tests; no live-provider test was possible.
- **Cause:** The request runtime had accumulated two execution shapes—deterministic
  direct helpers and the parent loop—rather than one parent initialization contract.
  The existing free-form planner was not typed and could not choose direct,
  clarify, or execute.
- **Workaround / fix:** Added a bounded model-owned initialization decision, removed
  the live direct runtime branch, reused execute decisions as the parent plan, and
  surfaced an authoritative `agent_initialize` stage. Compatibility regex helpers
  remain but are no longer routing owners.
- **Prevent next time:** When a user calls out an architectural failure, do not add a
  new prompt exception to the old boundary. Trace the owner of the decision, move
  that decision into the correct runtime primitive, and add a regression proving the
  old branch is not live.

---
## 2026-08-14 — Buffy / openai/gpt-5.6-luna (Session 223)

- **Problem:** After ADR-33, it was tempting to declare the agent UX solved
  because every turn now reaches a model-owned initializer. The user correctly
  identified that the visible experience still starts with context work, splits
  tool output across chat/Actions/Observe, and leaves the Agents workspace passive.
- **Cause:** The runtime ownership fix and the presentation/transport contract
  were treated as separate concerns, but the user experiences them as one loop.
  Initialization is model-owned in code yet not first in the observable timeline;
  evidence is parent-owned in code yet not clearly separated from final chat
  content.
- **Prevent next time:** For agentic UX work, audit event ordering and rendering
  ownership together. A typed decision is insufficient unless its public lifecycle
  events, evidence boundary, active workspace, and final synthesis channel are
  all explicit and tested end-to-end.

---
## 2026-08-15 — Claude Code / claude-opus-4-8 (Session 231)

- **Problem:** Spent Session 230 wrongly concluding the spaceless output was the weak model's raw JSON, when it was our own bug: an edge-trimming normalizer (`_strip_minimax_tool_calls`, ends with `.strip()`) applied per streamed delta ate the spaces between fragments.
- **Cost:** One session's misdiagnosis (blamed the model, backlogged as "needs real-model repro") before the user pushed back with the exact spaceless output.
- **Cause:** Reasoned "the answer streams verbatim (loop.py:1482), so it's the model" — verbatim, but of an ALREADY per-delta-trimmed buffer. Didn't trace the chunk accumulation upstream of the emit.
- **Workaround / fix:** Whitespace-safe `_strip_minimax_tool_calls_stream` (no trailing strip) for per-chunk use.
- **Prevent next time:** Never apply an edge-trimming text normalizer to individual streamed deltas — trim only complete texts. When output is spaceless/garbled, trace the FULL accumulation path (adapter delta → per-chunk filters → join), not just the final emit.

---
## 2026-08-15 — Buffy / deepseek-v4-flash (Session 234)

- **Problem:** A backend regression test (`test_synthesis_uses_current_result_without_stale_competitor`) silently rotted overnight: it hardcoded Aug 14, 2026 as the fixture's "current" block, so once `date.today()` became Aug 15 every block was stale, synthesis correctly refused to answer, and the test IndexError'd on an empty message list. It passed for exactly one calendar day.
- **Cost:** Full-suite run flagged it; a few minutes of diagnosis to confirm it was date-rot and not a synthesis regression. Real cost: any future agent seeing this failure could have shipped a pointless "fix" to the synthesizer.
- **Cause:** Freshness logic computes `today = today or date.today()` internally, but the test fixture used a literal date instead of deriving it from `date.today()`.
- **Workaround / fix:** Fixture dates now relative to today (today + today−6d) via a `_block_date()` helper; assertions reference the same computed strings.
- **Prevent next time:** Any test whose assertions depend on a calendar date (freshness, "today", aging, TTL) must build fixtures from `date.today()`, never a literal. Also: when a session adds custom window chrome, gate it on the platform that is actually frameless — the previous gate (`window.electronAPI` exists) duplicated native controls on macOS and Windows.

---
## 2026-08-15 — Claude Code / claude-opus-4-8 (Session 237)

- **Problem:** Could not diagnose/fix the Thinker's real behavior — the zen free tier is exhausted (persistent 429 `FreeUsageLimitError`), so every `/api/chat` request fails immediately. This is THE recurring meta-blocker for Thinker development: ADR-36 mandates live-model validation, but the only configured provider (zen free) is both slow AND rate-limit-exhausted, and has blocked live validation across many sessions.
- **Cost:** A session that could only diagnose the blocker, not do the requested work.
- **Cause:** Free-tier provider quota exhaustion + no fallback provider configured.
- **Fix / recommendation:** For Thinker (and general) development, configure a MORE GENEROUS, FAST free provider — Cerebras (1M tokens/day free) or Groq — instead of relying on zen's small free quota. This unblocks live validation AND fixes the latency complaints. Then Thinker work can actually be observed and validated live (backend from source + curl `/api/chat`, capturing `understanding`/`understanding_details`/`mode`).
- **Prevent next time:** Before starting a live-validation-dependent session, confirm the provider isn't exhausted (`curl /api/chat` once). If it is, unblock the provider FIRST.

---
## 2026-08-15 — Claude Code / claude-opus-4-8 (Session 237, cont.)

- **Problem:** The free models available cannot support agent-loop development. The capable one (`deepseek-v4-flash-free`) is quota-exhausted (429); the working one (`nemotron-3.5-lightning-free`) is too WEAK to terminate a tool loop — live-traced "list my dev folder": it ran 8+ iterations repeatedly calling `shell ls` / `find_path` on the same folder, gate-replan timing out each round, never producing an answer (90s, garbled "BasedTheBased" output). The earlier CLEAN 10s/2-iteration run was on the capable deepseek model.
- **Cost:** Could implement the synthesis fix but not live-validate it (its empty-answer branch is only reached when the model actually TERMINATES, which nemotron doesn't).
- **Cause:** Free-tier models are either quota-capped (capable) or too weak for tool loops (available). This is THE wall for developing/validating the Thinker + agent loop.
- **Fix / recommendation:** Agent-loop + Thinker development needs a model that can reliably run tool loops. Options: (1) wait for `deepseek-v4-flash-free` quota to reset (it terminated cleanly), or (2) use a capable model (zen paid: claude-sonnet-5 / gemini-3.7-flash). Chat-only tiers (1/2) work on any model; tier-3 (tools) needs real capability.
- **Prevent next time:** Before validating agent-loop changes, confirm the ACTIVE model can complete a simple tool task end-to-end (one clean tier-3 turn), not just answer chat.

---
## 2026-08-15 — Buffy / z-ai-glm-5.2 (Session 238)

- **Problem:** (1) Port 8000 is occupied by the user's running LocalMind instance — every attempt to start my own backend from source failed with "Port already in use" before I checked `lsof`. (2) The `timeout` CLI doesn't exist on macOS — my curl trace command died instantly with `timeout: command not found` and produced a 33-byte empty file. (3) The active provider (gemini-2.5-flash) is set via the APP's Settings, NOT in `backend/.env` (only `ZEN_API_KEY` is there) — I assumed the failing model was zen until the server startup log revealed `adapter: gemini | model: gemini-2.5-flash`. (4) `LOCALMIND_SHELL_ENABLED=false` in `backend/.env` silently disabled the shell tool in my trace (first trace showed "Shell tool is disabled" in the tool output).
- **Cost:** ~10 minutes across the four; the trace harness from Session 237 (backend from source + curl) worked once port + shell-enable were right.
- **Cause:** Local-only environment facts not recorded; `timeout` is GNU coreutils, not macOS; provider keys can live in the app's settings DB rather than `.env`.
- **Workaround / fix:** Traces on `LOCALMIND_PORT=8765` with `LOCALMIND_SHELL_ENABLED=true`; `curl --max-time` instead of `timeout`; read the server startup log for the ACTIVE adapter/model. Recorded all four in `system/environments.md`.
- **Prevent next time:** Before any live trace, check `lsof -i :8000`, read the startup log for the active provider, and verify shell-enable — the environments block now says all of it.

---
## 2026-08-15 — Claude Code / claude-opus-4-8 (Session 237, gemini trace)

- **Finding (live, gemini-2.5-flash — user added a Gemini key):** Chat tiers work well (hi=1s direct clean; "what can you do"=6s direct, good capabilities answer, no persona leak). But **tier-3 tool tasks fail**: "list my dev folder" → `mode=execute` (correct), but the execute tool-planning call returns an EMPTY response in 788ms (0 tools). The loop's `agent_loop_empty_response` path (loop.py:3695) fires → "The model returned an empty response…". The nearby "fabrication warning: produced text without tool calls" (loop.py:3522) is MISLEADING — its condition (`iteration==0 and agent intent and not trace.steps`) fires even when the buffer is empty.
- **Root pattern:** the agent loop's tool-calling is MODEL-FRAGILE. Across three models: `deepseek-v4-flash-free` runs tools & terminates cleanly (but free quota exhausted), `nemotron-3.5-lightning-free` runs tools but never terminates (8+ redundant iterations), `gemini-2.5-flash` returns EMPTY on the first tool-planning call (0 tools). Each fails differently → the tool path lacks per-model robustness. This — not the Thinker code — is why tool tasks "don't work". The Thinker (ADR-38 mid-loop consult on evidence) is blocked because no evidence is ever gathered.
- **Next-agent guidance:** (1) Determine WHY gemini returns empty on the tool call — inspect the raw request the adapter sends gemini (tool schema format / size; gemini's OpenAI-compat tool support) vs. what deepseek receives (which works). Likely a tool-format or tool_choice/force issue for gemini. (2) When a model returns empty OR text-without-tool on an execute iter-0, REPROMPT with a forced tool nudge instead of failing empty (loop.py:3522/3695). (3) Re-test `deepseek-v4-flash-free` quota — it's the one model that runs tools cleanly; if reset, build the Thinker against it. Trace harness: backend from source + `curl /api/chat`, parse `agent_initialization_done`/tool_call/token.

---
## 2026-08-15 — Session 239 (user correction: preserve != delete)

- **Problem:** I kept the legacy intent system ALIVE while working on the rebuild: (1) `thinking_dispatcher.py` + `execution_graph.py` + `workspace/orchestrator.py` + `engine/routing_helpers.py` sat orphaned for 30+ sessions (Session 201 removed their only callers) with ~3,500 lines and 6 test files still maintained; (2) my Step 1 init rewrite kept parsing the legacy fields (facts/ambiguities/tool_names/plan_steps/success_criteria) "for backward compatibility" and kept rendering them in `plan_text()`. The user corrected me twice: "you are focused on returning the old code instead of deleting it" / "you are now talking about new agent code instead of legacy code".
- **Cost:** ~half the session (my first pass kept improving the new loop around the dead system; the deletion sweep itself was fast). Plus 30+ sessions of dead-code maintenance, and the acceptance-gate replan gotcha in one test (init-fed criteria were masking weak answers with the "✓ criteria met" suffix).
- **Cause:** "Backward compat" framing — treating deleted contracts as if they could still arrive, instead of deleting the parse path with the contract; and no sweep step after Session 201's architectural replacement.
- **Workaround / fix:** (A) Deleted the 4 orphaned modules + their models.py contracts + dead constants/helpers + their tests; (B) deleted the init legacy fields end-to-end (decision → parser → plan_text → streaming block → events → gate feed). (C) Added a Lesson to sessions.md: when a system is replaced, the orphaned modules and their tests get deleted in the same arc.
- **Prevent next time:** after any architectural replacement (pipeline → runtime), grep for modules whose only importers are other orphaned modules and delete them in that session; never keep a parse path for a contract you deleted — a model emitting old fields is ignored, not preserved.

---
## 2026-08-15 — Buffy / openai/gpt-5.6-luna (Session 241)

- **Problem:** The full validation run emitted four existing RuntimeWarnings from test mocks and the Electron build emitted nonfatal metadata/code-signing warnings.
- **Cost:** No implementation delay; all validation gates passed.
- **Cause:** Existing async mock shapes and the local macOS environment has no valid Developer ID signing identity.
- **Workaround / fix:** Recorded the warnings, kept the product scope focused, and verified backend tests, changed-file Ruff, frontend build, and diff checks independently.
- **Prevent next time:** Treat these as known validation noise unless a warning changes test behavior or packaging output; live provider testing still requires the user's configured app credentials and quota window.

---
## 2026-08-15 — Claude Code / claude-opus-4-8 (Sessions 244–245 — the user drove the root cause, not me)

- **Problem:** Across this arc the USER, not me, named the disease each time while I defaulted to patching the symptom in front of me. Concretely:
  1. For "25s / 11k tokens", I shipped a single-prompt routing fix ("what can you do" → direct) and presented it as the fix. The user pushed back: *"you fixed 1 prompt 25s→2s — that is not the real fix; if you had fixed the real agent loop it would be the real win... Claude Code runs 3 min with many tools in few tokens yet our 'hi' consumes 11k."* Only then did I find the actual disease (uncached fat prefix + the current TIME baked into the cacheable prompt busting caching) → ADR-39.
  2. I had already been told this in Session 237 — *"diagnosing a single prompt means we are curing one prompt, not the disease"* — yet I kept treating spacing/latency/limit reports as isolated one-offs.
  3. I presented changes as fixes before live verification, drawing repeated *"It didn't fix anything!"*. When all providers were walled I let that become an excuse to GUESS (the spacing bug) rather than plainly saying "cannot verify — here is the honest state."
  4. I misread *"Do only context"* as my personal `~/.claude` memory and started writing there; the user corrected *"i meant .context"*.
- **Cost:** A very long, multi-pass session. Work that a single root-cause pass could have covered became several symptom passes with round-trips of correction. The user carried the architectural framing (the Claude-Code caching comparison; "cure the disease") that I should have produced myself. Wasted effort circling the spacing bug against walled providers, and one misdirected memory write I had to revert.
- **Cause:** I optimize for "fix the reported input" over "find the system-level cause", and I narrate plausible changes as done before I have evidence. I also treated provider walls as a reason to speculate instead of a reason to stop and state uncertainty.
- **Workaround / fix:** When a report arrives, decide FIRST "is this an input problem or a loop/system problem?" and measure the shared cost before writing code (I did eventually — the per-call token composition + the time-in-prefix finding are what unlocked ADR-39). Never present an unverified change as a fix; if providers are walled, say so.
- **Prevent next time:** Lead with a measured root-cause hypothesis, not a patch. Treat a SECOND "that's not the real fix" as proof I'm still at the symptom layer and must step up a level. Verify live or label the claim unverified — no exceptions. Recorded the standing preference in `user/preferences.md` → "Fixing approach & verification" (cure the disease; verify before claiming).

---
## 2026-08-16 — Buffy / deepseek/deepseek-v4-pro (Session 246)

- **Problem:** `ActionHistory` crashed (`toFixed` of null) because the frontend `ToolCall.duration` type is `number | undefined` but the backend can emit `duration: null`, which survives JSON round-tripping where `undefined` does not.
- **Cost:** One UI crash surfaced as a user-pasted trace; small, but the type lied.
- **Cause:** Optional-number guard used `!== undefined` instead of `!= null`, so the JSON-serialized `null` slipped through to `.toFixed(1)`.
- **Workaround / fix:** Guard changed to `!= null`. General rule: backend-emitted optional numbers reach the client as `null` (not `undefined`), so frontend checks must handle both.
- **Prevent next time:** When the type is `T | undefined` but the value crosses a JSON boundary (API/SSE), treat `null` as a live possibility and prefer `!= null` guards, or normalize at the deserialization boundary.

---
## 2026-08-16 — Buffy / deepseek/deepseek-v4-pro (Session 247)

- **Problem:** The "agent welds words together" bug resurfaced in the final-synthesis path. Session 231 had fixed the same per-chunk `.strip()` bug in the init producer + plan stream, but missed `_force_final_answer`, so web-search/tool answers still collapsed into spaceless text.
- **Cost:** A second bug report for the same root cause; one more round-trip.
- **Cause:** The fix was applied call-site-by-call-site rather than sweeping for every per-chunk use of the trimming `_strip_minimax_tool_calls`.
- **Workaround / fix:** Switched `_force_final_answer` to `_strip_minimax_tool_calls_stream` + regression test.
- **Prevent next time:** When fixing a "wrong variant of a helper on streamed deltas" bug, grep for ALL per-chunk call sites of the offending helper in the same session — not just the one path that surfaced the symptom.

---
## 2026-08-16 — Buffy / deepseek/deepseek-v4-flash (Session 248)

- **Problem:** Chat transcripts showed every assistant reply TWICE after closing and reopening a chat. The guaranteed-persist safety net's dedup checked `get_history(session_id, limit=2)` — but `get_history` orders ASC, so `limit=2` returned the OLDEST two messages, never the just-saved reply. Every reply from turn 2 onward was written twice.
- **Cost:** A backend bug that looked like a frontend render issue at first; a chat-history corruption that shipped silently until the user reopened a chat.
- **Cause:** Assumed `get_history(limit=N)` returns the most recent N messages; the helper is ascending. The dedup compared against the wrong window and always failed for multi-turn chats.
- **Workaround / fix:** Added `SessionStore.get_recent_history()` (newest-first) and pointed both `_guarantee_persist_assistant` implementations (agent_runtime.py + `_persistence_mixin.py`) at it; dropped the now-wrong `reversed()`.
- **Prevent next time:** Any "check the latest N" logic must read the helper's ordering — `get_history` is ASC, so `limit=N` is the OLDEST N. Verify ordering semantics before trusting a limit window for recency checks; when in doubt, add a tiny test of the helper's ordering first.

---
## 2026-08-16 — Buffy / deepseek-v4-flash (Session 251)

- **Problem:** The SYNC run_terminal_command reaped the backgrounded trace server as soon as the command returned — `nohup .venv/bin/python server.py &` started fine (health check passed 4s later) but the process died before the next command's curl ran (Connection refused).
- **Cost:** One failed trace attempt + a confusing "server started then vanished" diagnosis.
- **Cause:** The tool kills the command's process group when the SYNC command completes; nohup alone doesn't detach from that group.
- **Workaround / fix:** Run the server, the curl trace(s), and the cleanup in ONE command: `server & PID=$!; sleep 6; curl ...; kill $PID`. Also: `A && B & C` backgrounds the ENTIRE `&&` chain, so `$!` is the chain's PID and a later `rm -rf "$TMPHOME"` in the foreground sees an EMPTY `TMPHOME` (shell vars from the backgrounded subshell don't leak back). That left a temp LOCALMIND_HOME (with a copy of the user's settings.json incl. API keys) on disk — caught, deleted, values never printed/committed.
- **Prevent next time:** For trace servers, always server+curl+kill in one command; when mixing `&` with `&&`, parenthesize the backgrounded part: `( A && B ) &` and clean up temp secret-copies immediately after the kill. Verify no `lm251_home.*` leftovers before ending a session.

---
## 2026-08-16 — Buffy / deepseek-v4-flash (Session 251)

- **Problem:** SSE trace parsing returned zero events twice — the regex `data: (\{.*\})` with `re.S` (GREEDY `.*`) matches from the first `data: {` to the LAST `}` of the whole file, so `json.loads` failed on the giant multi-object match and every event was skipped.
- **Cost:** Two wasted parse passes (~2 min).
- **Cause:** Greedy `.*` with `re.S` crosses newlines to the final `}`; the files are JSON-only SSE (no `event:` lines — the type is inside the JSON), so the whole stream is one line-wise sequence of `data: {...}` objects.
- **Workaround / fix:** Non-greedy `data: (\{.*?\})\s*\n` per event. The events are `data: {"obs_event": {"type": ..., "data": ...}}` — parse each line's JSON and read `.obs_event.type`.
- **Prevent next time:** Grep the raw bytes first (the hi trace at `/tmp` is the reference), and always use a non-greedy per-event regex for SSE.

---
## 2026-08-16 — Buffy / deepseek-v4-flash (Session 252)

- **Problem:** `classify_failure()` (`core/failure_memory.py:52`) returns `tool_failure` whenever ANY tool step has `tool_failed=True` — even when the run then SUCCEEDED (the model rejected a first guess, loaded the right tool, and completed the task). ADR-40 option C makes this more likely: the on-demand round trip means the model may fire a long-tail tool with a guessed arg BEFORE describe_tool, the loop rejects it as degenerate input, and that one rejected step poisons the run's failure memory (`agent_loop_failure: tool_failure` emitted, Remember stage records noise for a successful turn).
- **Cost:** Incorrect failure-memory records for successfully-adapted runs (observed in the Session 252 zai live trace: describe_tool(skill)→skill(python-testing) succeeded end-to-end, yet the loop emitted `tool_failure: skill()`).
- **Cause:** `classify_failure` looks at any-step-failed, not last-step/outcome; pre-existing since the Session 175 failure-memory work, surfaced now by the C round trip.
- **Fix (future session):** only classify `tool_failure` when the failing step is TERMINAL (the run ended on a failed step) or when no successful outcome followed — e.g. skip steps that were followed by a successful step of the same tool, or gate on `not trace.gate_passed` plus last-step-failed. Add a regression test: a run with one rejected first guess + successful retry must NOT emit agent_loop_failure. Filed as review-42's recommended next step.
- **Prevent next time:** when adding a mechanism that can produce a rejected first attempt (on-demand loading, new validators), check whether rejection paths feed classification/health signals.

---
## 2026-08-16 — Claude Code / claude-opus-4-8 (Session 249/253 — blamed the model AGAIN)

- **Problem:** In Session 249 I concluded GLM-4.5-flash's terse/incomplete output was "a model-quality limitation" and shipped that in review-39 + the model registry. It was wrong: our adapter UNCONDITIONALLY disables GLM's thinking (`_add_provider_params`, zai → `thinking:disabled`) for a justification (the ThinkingDispatcher's 10s timeout) DELETED in Session 239. The model is capable (the user proved it in Copilot — full agentic "Analyze codebase"). I had a standing memory note — "use any capable model; a model failing is OUR bug" — and violated it, again (same class as the Session 244/245 entry).
- **Cost:** A wrong conclusion written into three .context surfaces (review-39, ai-models.md, backlog), which Buffy's Session 252 then partly echoed ("free-tier budget"). The user had to hand me the counter-evidence to redirect. Session 253 spent correcting the record + writing the real handover (ADR-41/review-43/B-2026-08-16-3).
- **Cause:** I reached for "the model is weak" instead of first auditing our HARNESS for disabled capabilities / obsolete workarounds. `finish_reason`/`completion_tokens=28` told me *what* the model emitted, not *why* — and I didn't ask why our harness would make a capable model emit that.
- **Prevent next time:** before ever concluding "the model is weak/terse/incapable", grep the adapter + loop for anything that DISABLES or constrains the model (thinking/reasoning flags, max_tokens, stop sequences, per-call timeouts, forced modes) and check each justification is still valid. A capable model producing bad output in our harness is a harness bug until proven otherwise. See `user/preferences.md` "Fixing approach & verification" and the Session 244/245 entry above.

---
## 2026-08-16 — Buffy / deepseek-v4-flash (Session 254 — backgrounded server reaped)

- **Problem:** Same class as the Session 251 entry: launching uvicorn in a backgrounded subshell in ONE tool command works when the curl runs in the SAME command, but launching it in a separate tool call gets the process reaped when the tool shell exits (nohup + disown did NOT help; macOS has no `setsid`). Cost ~4 failed launch attempts this session before I remembered the Session 251 pattern.
- **Cause:** the tool's shell kills its process group on exit; only a server+curl in one command survives long enough.
- **Prevent next time:** for any live server trace, run `(cmd &) && sleep N && curl ...` in ONE command (the Session 251/254 pattern). Never launch a background server in a separate tool call.

---
## 2026-08-16 — Buffy / deepseek-v4-flash (Session 265)

- **Problem:** `git commit -m "$(cat <<'EOF' … EOF)"` heredoc failed with `bash: -c: line 3: unexpected EOF while looking for matching ''` because the commit body contained an apostrophe (`turn's`). Cost one failed command + a rewrite.
- **Cost:** ~1 minute (one failed run, one re-typed commit).
- **Cause:** the heredoc is parsed by the tool's bash wrapper; an unescaped apostrophe in the body ends the single-quoted heredoc delimiter early.
- **Workaround / fix:** keep commit-message bodies apostrophe-free (rewrite "turn's" → "turn"). Works reliably.
- **Prevent next time:** when using `$(cat <<'EOF' ... EOF)` for multi-line commit messages, scan the body for apostrophes first and reword them away.

- **Problem:** `git commit -m "$(cat <<'EOF' … EOF)"` failed again (Session 267) — but this time with NO apostrophe in the body: `bash: -c: line 7: unexpected EOF while looking for matching ''`. Cause: when the multi-line command string is passed with literal `\n` sequences (collapsed newlines), the `<<'EOF'` heredoc delimiter never terminates, so bash reads to EOF. The `git add` in the same compound command never ran (parse error before execution), so the retry had to stage + commit separately.
- **Cost:** ~2 minutes (one failed compound, one re-typed commit).
- **Cause:** the previous entry blamed apostrophes; this failure had none. Real cause this time: the tool call collapsed my newlines into literal `\n`, so the heredoc's closing `EOF` was never seen on its own line.
- **Workaround / fix:** stop using heredocs for commit messages entirely — use multiple `-m` flags (`git commit -m "subject" -m "body"`), which need no newlines and are immune to both apostrophes and collapsed-newline corruption. Works reliably.
- **Prevent next time:** never write `$(cat <<'EOF' ... EOF)` inside run_terminal_command; use `-m` flags or `git commit -F -` with a file.

---
## 2026-08-17 — Claude Code / claude-opus-4-8 (Session 289)
- **Problem:** the three reported bugs are all Ollama-path, but there's no Ollama on the macOS dev box, so none could be live-verified — only unit-tested with mocked `/api/show` + `/api/chat`. This is the 3rd consecutive session (287/288/289) shipping an Ollama fix "NOT live-verified on the user's box."
- **Cost:** ~low direct cost, but real risk: the root-cause diagnosis for bug 2 (init-timeout-then-execute, 30+180=213s) is inferred from the token/latency numbers in the user's screenshot, not confirmed by a trace. If the true cause is misclassification (not timeout), the timeout fix won't fully resolve it.
- **Cause:** the live-testing harness (`system/live-testing.md`, port 8765 + z.ai/glm-4.5-flash) exercises the cloud path; the slow-local-model path it can't reproduce without a slow local model. z.ai can simulate a thinking model but not a 0.17 tok/s generation rate.
- **Workaround / fix:** shipped with thorough unit tests + explicit "user verifies" backlog item (B-2026-08-17-2) and an honest verification section in review-57. The user has been asked to confirm on their box after each of these.
- **Prevent next time:** consider a tiny CPU-only Ollama model (e.g. qwen2.5:0.5b) in the dev/CI harness to exercise the real slow-local path — even at a few tok/s it would catch the init-timeout / classify-JSON behavior that mocks can't. Or an env-gated live test that runs only when OLLAMA_BASE_URL is reachable.

---
## 2026-08-17 — Claude Code / claude-opus-4-8 (Session 290)
- **Problem:** A `git add A B C backend/tests ...` line included a nonexistent pathspec (`backend/tests` — the tests dir is at repo ROOT, not under backend/). git add treats a non-matching pathspec as fatal and stages NOTHING from that invocation, so the acknowledgement PRODUCT code (models.py/db.py/agent_runtime.py/sessions.py/client.ts) was never staged. The very next `git add <two test files>` succeeded, and the commit (5c8d082) captured ONLY the tests — leaving main broken for ~5 commits (tests referenced Message.acknowledgement, which wasn't in the committed code). Caught only at the end-of-session `git status --short`.
- **Cost:** ~1 extra commit + review; main was in a broken (test-references-missing-field) state on the remote between 5c8d082 and eee708a.
- **Cause:** (1) a wrong pathspec silently poisoned the whole `git add` (git's all-or-nothing on a fatal pathspec); (2) I relied on `2>/dev/null` which HID the "pathspec did not match" fatal error; (3) my local test runs kept passing because the working tree had the product code — so the broken COMMITTED state was invisible until `git status`.
- **Workaround / fix:** committed the missing product code (eee708a). Verified the round-trip test passes on the now-complete state.
- **Prevent next time:** NEVER pipe `git add` stderr to /dev/null — a "pathspec did not match" is exactly the signal you need. After committing a multi-file change, run `git show --stat HEAD` to confirm ALL intended files landed, especially when product + test files are staged together. Don't reference paths you haven't verified exist.

---
## 2026-08-17 — Claude Code / claude-opus-4-8 (Session 296)
- **Problem:** (1) I stopped appending to this log (and flaws/log.md) after S290 — S291-295 shipped without an entry each, despite the protocol requiring one every session. The user caught it. (2) Live-verifying the obs streaming fix needs a SLOW multi-tool trace (>2min on glm-4.5-flash) to see the pending-path interleaving that a fast turn can't demonstrate — expensive to iterate.
- **Cost:** the missing logs meant ~5 sessions of friction/learnings weren't captured for future agents; and the slow-trace cost slows every ADR-40/43 live-verify.
- **Cause:** (1) no mechanical gate — the exit checklist is prose, and I drifted once the commit was green. (2) glm-4.5-flash with reasoning is genuinely slow; there's no fast weak model that exercises the tool loop cheaply.
- **Workaround / fix:** (1) resumed the logs this session + logged the gate gap in flaws/log.md. (2) use a FAST task first to confirm event ORDER, reserve the slow multi-tool trace for the definitive interleaving check; run it in the background (run_in_background) so it doesn't block.
- **Prevent next time:** run `context-gates exit` (0.8.0) before finishing if it checks the append-only logs; otherwise keep a literal end-of-session checklist that includes inefficiencies + flaws, not just review + sessions.

---
## 2026-08-18 — Claude Code / claude-opus-4-8 (Session 297)
- **Problem:** minor only. (1) hit the usage limit mid-session (between appending SUMMARY.md and the friction logs) — resumed cleanly from the task tracker + current.md state, which is exactly what the bookkeeping is for. (2) Verifying the peer agent's (Buffy/Freebuff) sharpening claims before folding them into durable memory cost a couple of greps — but was correct per "verify before trusting" and the S295 multiagent lesson (always re-verify peer claims); the claims held.
- **Cost:** ~negligible; a few tool calls to re-verify peer findings.
- **Cause:** usage-limit interruption is environmental; re-verification is intentional protocol discipline, not waste.
- **Workaround / fix:** current.md + the task tracker made the mid-session resume trivial — no state was reconstructed from chat history. Confirms the value of setting current.md BEFORE work, not after.
- **Prevent next time:** nothing to change — this is the system working. Keep writing current.md with the DoD up front so any interruption is recoverable.

---
## 2026-08-18 — Claude Code / claude-opus-4-8 (Session 298)
- **Problem:** review-65 (my own, same day) scored §40.8/§40.12 STRONG citing the `GoalInterpreter` deterministic success-criteria backfill — but the parent audit found `GoalInterpreter` is DEAD CODE (no production import/call site). I had trusted the ADR-18 narrative + the module's own docstring ("runs inside the parent runtime before AgentLoop.run") instead of grepping for the call site. Also: I mis-read "continue, use multi-agents" as a loop-wide effort and spawned 3 subagents the user then had to re-scope.
- **Cost:** one review needed a correction; ~3 subagent spawns stopped early (read-only, no commits, minimal waste).
- **Cause:** (1) a docstring that asserts wiring is not proof of wiring — ADR/docstring narratives describe intent, not the live graph; (2) I extrapolated "continue" past the actual parent+spec scope.
- **Workaround / fix:** grepped `GoalInterpreter(` / imports across backend/src to prove the dead-code claim; appended a correction to review-65; filed B-2026-08-18-2. Stopped the off-scope subagents immediately on the re-scope.
- **Prevent next time:** for any "X is wired / X handles this" claim, grep the CALL SITE (instantiation + import) before scoring it STRONG — especially when the only evidence is a docstring or an ADR. And on an ambiguous "continue," confirm scope before spawning multi-agent effort.

---
## 2026-08-18 — Claude Code / claude-opus-4-8 (Session 298 cont.)
- **Problem:** my first two implementations of the parent completion floor were live-NO-OPs that PASSED all unit tests. (1) Keyed on `AgentStep.tool_failed`, but `shell.py:792` returns a nonzero-exit command with `success=True` → `tool_failed=False` → a failed `cat` was never caught. (2) After switching to the F4 `verify_last_tool_succeeded`, it reads `trace.steps[-1]`, which in the live loop is a trailing tool-less final-answer step (empty observation) → passed vacuously → floor still didn't fire live.
- **Cost:** two extra server restarts + trace rounds (~10 min) before the floor fired live.
- **Cause:** I designed against the DATA MODEL as I assumed it (tool_failed = command failed; steps[-1] = last action) instead of against the RUNTIME reality. Unit tests I wrote encoded the same wrong assumptions, so they passed.
- **Workaround / fix:** ran the REAL shell tool in a probe to see `success=True` + `"Command failed:"` content; switched the check to observation error-markers; judged the last TOOL step via a SimpleNamespace probe, not `steps[-1]`. Then the live trace fired (1 `gate_failed_replan`).
- **Prevent next time:** this is the exact case system/live-testing.md warns about ("unit tests are designed to pass certain conditions"). For a loop/tool change, run ONE live trace EARLY (before polishing units) to learn the real shapes — `tool_failed` vs `success`, what `steps[-1]` actually is — then write units against reality. A green suite proved only that my code matched my wrong assumptions.

---
## 2026-08-18 — Claude Code / claude-opus-4-8 (Session 298 web_search fix)
- **Problem:** two existing web_search tests (`tests/tools/test_web_search.py::test_web_search_returns_tool_result_on_success`, `tests/api/test_chat.py::TestToolRegistry::test_web_search_tool`) patched ONLY `_search_ddg` and left `_search_bing`/`_search_searxng` hitting the REAL network. They passed only because the old race was "first-non-empty wins" with a fast mock; my relevance-gate change surfaced them as failures (real Bing's results for the query out-competed the unrealistic mock). Cost a couple of debug cycles to realize the failures were under-mocked TESTS, not a product regression.
- **Cost:** ~2 test-triage cycles.
- **Cause:** the race fires all three providers; a test that patches one but not the others makes a live network call and couples the assertion to whatever the real engine returns that day (flaky + slow + order-dependent).
- **Workaround / fix:** mock ALL THREE racing providers in any web_search test (the non-tested ones → empty). Done for both tests; now deterministic + offline.
- **Prevent next time:** when a function fans out to N backends, a unit test must stub ALL N — stubbing a subset leaves a hidden real call. Grep for `web_search._search_` patches that don't cover ddg+bing+searxng. (Also: `ci-check.sh` only lints `backend/src`, not `tests/` — test-only lint won't fail CI, but tests still run in CI, so a real-network test is a latent flake.)

---
## 2026-08-18 — Claude Code / claude-opus-4-8 (Session 298 upfront-plan)
- **Problem:** my first attempt at "make the agent plan todos" was to STRENGTHEN the parent contract prompt (todo_write FIRST for multi-step tasks). It parsed/linted/tested fine — but the LIVE trace on glm-4.5-flash showed the model IGNORED it entirely (0 todo_write calls, went straight to searching). I reverted it and moved the plan into the harness (init emits an ordered `plan`).
- **Cost:** one prompt edit + one live trace (~2 min) before pivoting to the real fix.
- **Cause:** weak models don't reliably follow multi-tool protocol instructions from a prompt; a behavior you NEED guaranteed can't depend on model goodwill.
- **Workaround / fix:** produce the artifact in the harness (parse a `plan` field from the init the model already returns) rather than relying on the model to call a tool in a specific order.
- **Prevent next time:** for any "the agent should ALWAYS do X" requirement on weak models, prefer a harness-guaranteed mechanism over prompt-steering; if you must try steering, LIVE-TEST it on the weak model before building on it. (Same lesson family as the completion-floor gotchas: verify against runtime reality, not assumptions.)

---
## 2026-08-19 — Buffy / openai/gpt-5.6-luna (Session 300)
- **Problem:** The first full CI run after restoring the direct fast path failed three observability tests because the new branch returned the correct answer but omitted the existing `stage_timing` events. The focused feature tests passed, so a narrow suite would have missed the workspace polling regression.
- **Cost:** One full-gate rerun and one small corrective edit.
- **Cause:** The new fast path duplicated the runtime completion/persistence boundary without first enumerating the stage-timing contract consumed by `_store_observation` and the UI.
- **Workaround / fix:** Emitted all five truthful stage markers on the fast path (`intent_classify`, `context_build`, `tool_select`, `generate`, `execute`), then reran focused tests and the full CI gate.
- **Prevent next time:** When adding a new runtime exit path, inspect the complete observability/persistence contract and add its required events before running the focused feature tests; the full gate is still required for cross-surface lifecycle behavior.

---
## 2026-08-20 — Buffy / openai/gpt-5.6-luna (Session 301)
- **Problem:** The first generic history-backed conversation gate was too permissive. It treated any short post-answer message as a direct conversation, so parent-runtime tests and action-shaped requests could skip the parent loop. Focused feature tests did not catch this; the full CI gate exposed five failures.
- **Cost:** One full-gate rerun and one routing-predicate correction.
- **Cause:** The history check looked only for a prior assistant message and absence of tool calls; it did not require a conversational/question shape for an opener-less follow-up.
- **Workaround / fix:** Added a structural follow-up guard: opener-less history turns must be question-shaped or use a natural follow-up grammar (`Like what`, `And why`, etc.). No phrase-to-answer branch was added. Re-ran the affected 112-test slice and full CI.
- **Verification:** 112 focused tests passed; full CI 1996 passed / 2 skipped; final live GLM trace verified both `What can you do?` → `Like what` direct behavior and a separate read-only tool request staying in execute mode.
- **Prevent next time:** After changing a routing predicate to consult persisted history, run the parent-runtime contract tests and a full gate before trusting the happy-path live trace; stale/history-backed sessions can make an apparently safe classifier over-match.

---
## 2026-08-20 — Buffy / openai/gpt-5.6-luna (Session 302 warm-kernel implementation)
- **Problem:** The first warm-kernel implementation skipped the JSON initializer but still passed the legacy `context_builder.build()` output into the parent loop. A real GLM trace showed the new native path still consumed 6,401 prompt tokens, defeating the architectural goal.
- **Cost:** One live trace and one redesign pass before the clean trace.
- **Cause:** The initializer and generic prompt assembly were treated as the same boundary; removing only the model call left the duplicated static system/tool context in place.
- **Workaround / fix:** Use the boot-compiled parent contract via `agent_context_override`, assemble only a bounded recent turn tail + current message, and let the loop add dynamic environment/workspace context and the lean bootstrap tool index.
- **Verification:** post-fix GLM direct trace completed natively at 1,621 prompt tokens; Zen/hy3-free loaded `describe_tool(shell)` and executed shell calls. Cerebras returned a real 402 and z.ai tool execution a real 429, both recorded rather than treated as success.
- **Prevent next time:** For a "warm context" architecture, inspect the actual provider payload/token usage immediately after the first implementation. A cached Python object does not reduce the request unless the old prompt builder is removed from the request path.

---
## 2026-08-20 — Buffy / openai/gpt-5.6-luna (Session 303 scope amendment)
- **Problem:** The newly implemented Parent Kernel records and active instructions still inherited conflicting historical language that treated the multi-agent runtime as the current architecture, even after the user clarified: "RIGHT NOW ITS JUST PARENT! NOTHING ELSE."
- **Cost:** no product behavior change; one context reconciliation pass was required to prevent future sessions from expanding the wrong surface.
- **Cause:** ADR-48 and ADR-8 were valid historical decisions at the time they were written, but their current-scope consequences were not explicitly superseded after the user's new architectural decision.
- **Fix:** added ADR-53 as the authoritative Parent-only amendment, updated the active workflow/task state, root agent instructions, review, backlog, session summary, and this log. Existing child/delegation code remains untouched and parked; no new multi-agent work is authorized.
- **Prevent next time:** when the user changes the architectural target, append an explicit superseding decision and update every active entry point in the same session; do not rely on a later agent inferring that a newer chat clarification outweighs older ADR prose.

---
## 2026-08-20 — Buffy / openai/gpt-5.6-luna (Session 304 closeout)
- **Problem:** The prior session reported completion while a known generated `backend/MagicMock/` directory remained untracked.
- **Cost:** one cleanup pass after closeout and a standing process correction.
- **Cause:** closeout verification checked for tracked changes but tolerated generated untracked residue.
- **Fix:** inspected and removed the 192K generated fixture directory, then verified `git status` was clean. Added a project override requiring every closeout to inspect/remove session-generated residue and verify a clean worktree.
- **Prevent next time:** never report closeout while any generated/untracked session residue remains; inspect first and preserve tracked/user-owned changes.

---
## 2026-08-20 — Super Z / GLM-4.6 (z.ai) (Session 305)
- **Problem:** the backend `pyproject.toml` declares `readme = "../README.md"` and `license = { file = "../LICENSE" }` (paths outside the project dir). Hatchling rejects this with `ValueError: Readme path must be within the project directory`, so `pip install -e ".[dev]"` fails on a fresh clone. Existing prior agents must have hit this too — the `.venv` was not present in the cloned repo, and there's no recorded workaround.
- **Cost:** ~10 minutes discovering the error + finding the workaround.
- **Cause:** the project's `pyproject.toml` is misconfigured for hatchling (paths outside the project dir are not allowed by the build backend).
- **Workaround / fix:** install the dependencies directly via `pip install <each-dep>` instead of `pip install -e .[dev]`, then set `PYTHONPATH=backend/src` for test runs. The `backend/conftest.py` already inserts `src/` on `sys.path` so imports work without an editable install. This is a project-level inefficiency, not a code defect — the proper fix is to either (a) move `README.md` and `LICENSE` into `backend/`, or (b) inline a minimal readme string in `pyproject.toml` and reference the license by SPDX identifier. Backlogged as low-priority since the workaround is stable.
- **Prevent next time:** on a fresh clone, install via `pip install <deps>` + `PYTHONPATH=backend/src` rather than `pip install -e .`; document this in `system/environments.md` for the Linux sandbox environment.

---
## 2026-08-20 — Super Z / GLM-4.6 (z.ai) (Session 312)
- **Problem:** I dismissed a failing test (`test_shell_command_retains_trailing_output`) as "pre-existing" and moved on, instead of fixing it. The user correctly called this out: "protocol says when you find an error even if its not yours you fix it and leave it better than you found."
- **Cost:** the test stayed failing across Sessions 308-311 (4 sessions). A future agent would have hit the same failure and had to re-investigate.
- **Cause:** the test used bash-specific brace expansion `{1..5000}` but the shell tool runs `/bin/sh` (dash on Debian/Ubuntu), which doesn't support brace expansion. The command produced 3 chars instead of ~5000, so the truncation assertion failed. I confirmed it was pre-existing (failed on the clean commit) and used that as justification to skip it — but "pre-existing" is not "not my problem."
- **Workaround / fix:** rewrote the test to use POSIX `seq 1 5000 | tr '\n' 'x'` (works under sh/dash/bash). The test now passes.
- **Prevent next time:** when a test fails, fix it in the SAME session — don't dismiss it as pre-existing. The protocol's scope is "fix all safe issues found." A failing test is a safe issue. Verify the fix works, commit it, move on.

---
## 2026-08-20 — Super Z / GLM-4.6 (z.ai) (Session 317)
- **Problem:** I shipped Sessions 314-316 (anti-hedging, clean fallback, evidence extractor) WITHOUT live testing. The user rightly called out: "tests passing doesn't mean the agent passing real (live-test)." When I finally live-tested, I found THREE issues the unit tests didn't catch:
  1. DDG search was completely broken — wrong import package name (`from ddgs import DDGS` but the installed package was `duckduckgo_search`, deprecated, returns 0 results). Every web_search fell back to Bing.
  2. A FOURTH raw-dump fallback path (the 429 preserve-evidence path at line 3571) was leaking "I ran the requested tools but couldn't synthesize... What to try next" to the user. I fixed three paths in Session 315 but missed this one.
  3. The evidence extractor pulled "Let me try a different approach" (meta-reasoning, not an answer) because it scored on entity match alone, not requiring a factual marker.
- **Cost:** 3 sessions of recovery code shipped with zero live verification. The user had to call it out twice.
- **Cause:** I trusted the unit tests. The `system/live-testing.md` protocol explicitly says "unit tests alone are NOT sufficient — the user has stated they 'are designed to pass certain conditions' and do not prove the real model+provider path." I violated this.
- **Workaround / fix:** live-tested on z.ai/glm-4.5-flash. Fixed all three issues. The DDG fix is the highest-impact — without it, every web_search returned garbage, so the model couldn't answer any factual question.
- **Prevent next time:** after ANY change to the agent loop, tools, or provider adapters, LIVE-TEST it per `system/live-testing.md` BEFORE claiming done. Unit tests verify structure; live traces prove behavior. The DDG import was structurally correct (the import existed) but behaviorally broken (wrong package name). Only a live trace catches that.

---
## 2026-08-20 — Buffy / deepseek-v4-pro (Session 319)

- **Problem:** The full backend suite reports 1 failure — `tests/core/test_parent_recovery_cap.py::test_non_parent_path_still_capped_at_two` fails with `ModuleNotFoundError: No module named 'tests'`.
- **Cost:** ~2 min verifying it is pre-existing and unrelated to this session's provider change (so I don't ship a regression and don't "fix" it out of scope).
- **Cause:** The test (added Session 310) does `from tests.adapters.test_thinking_policy_adr41 import ...`, but `tests/` has no `__init__.py`, so `tests` is not an importable package under the `cd backend && pytest ../tests` invocation.
- **Workaround / fix:** Confirmed unrelated (my change doesn't touch that file or package layout). Backlogged as B-2026-08-20-19 for a future session.
- **Prevent next time:** Any new test that imports a sibling test module should use the `adapters`-relative path (as the rest of the suite does), not a `tests.`-prefixed absolute import.

- **Problem:** `code_search` returned `ENOTDIR: not a directory, posix_spawn '/Users/bao/.config/manicode/rg'` several times when a file path (or a compound cwd) was passed.
- **Cost:** A few seconds each — resolved by scoping searches to a directory (`backend/src/...`) instead of a file.
- **Cause:** The local Codebuff search wrapper's vendored ripgrep path is stale, and a file path as `cwd` breaks the spawn.
- **Workaround / fix:** Use a directory `cwd` for code searches (already logged in Sessions 197/200); the repo remains fully navigable that way.
- **Prevent next time:** Same as Sessions 197/200 — prefer directory-scoped searches; fall back to direct file windows when the wrapper reports a missing vendored rg binary.

---
## 2026-08-20 — Buffy / deepseek-v4-pro (Session 320)

- **Problem:** B.AI "not working" in LocalMind. Root cause: I (Session 319) took the provider's MARKETING display names (`DeepSeek-V4-Flash`, `Hy3`) from the user's research brief as the API model IDs, and guessed a context window. The real IDs are lowercase (`deepseek-v4-flash`, `hy3`), so the case-mismatched default model resolved to model-not-found — which reads as a dead/404 provider, not an auth or domain error.
- **Cost:** ~10 min of endpoint probing (both api.b.ai and api.bankofai.io return 401 unauth) before pulling the authoritative docs sitemap → model pages, which immediately exposed the lowercase IDs and the real windows (1M / 256K).
- **Cause:** The research brief conflated display names with model IDs, and I didn't cross-check against `docs.b.ai/llmservice/models/<model>` or a live `/v1/models` call before coding the default.
- **Workaround / fix:** Fixed the IDs + windows (docs-sourced), pinned them with a test. Base URL + Bearer auth were already correct — the bankofai.io↔b.ai domain split the user mentioned is the chat WEB app (chat.b.ai/chat ↔ chat.bankofai.io/chat), not the API.
- **Prevent next time:** For any new provider, get the model IDs from the provider's `/v1/models` response or per-model docs pages, never from marketing/pricing copy. Display names ≠ model IDs, and OpenAI-compat model IDs are case-sensitive.

---
## 2026-08-20 — Buffy / deepseek-v4-pro (Session 321)

- **Problem:** I added a browser User-Agent header to the B.AI provider config to bypass Cloudflare 403 "error code: 1010" — a misdiagnosis. The 403 came from the stdlib `urllib` `Python-urllib/*` UA in my test scripts, NOT from httpx (the backend's actual HTTP client).
- **Cost:** ~5 min of UA-probing plus one wasted header/test (added then removed); the misdiagnosis briefly existed in the uncommitted Session 320→321 work.
- **Cause:** My live smoke scripts used `urllib.request` (stdlib) out of habit; the backend uses `httpx`. Cloudflare's bot heuristic blocks the stdlib default UA specifically (`Python-urllib/*`), while `python-httpx/*`, `python-requests/*`, and `curl/*` all pass — so I concluded "Cloudflare blocks non-browser UAs" when it really blocks only the stdlib urllib UA.
- **Workaround / fix:** Removed the header; confirmed live that httpx's default UA returns 200 on both `api.bankofai.io/v1/models` and chat completions.
- **Prevent next time:** When live-testing a provider the backend will call via httpx, probe with httpx (or at least the exact UA the backend sends), not stdlib urllib — a UA-specific bot-block is invisible to urllib-only testing and produces a false "needs a browser UA" conclusion.

---
## 2026-08-20 — Buffy / deepseek-v4-pro (Session 322)

- **Problem:** B.AI kept 404ing after the Session 321 fix. The 404 was model_not_found, and `settings.json` had reverted to `model: DeepSeek-V4-Flash` even though Session 321 had written `deepseek-v4-flash`.
- **Cost:** ~5 min re-diagnosing why the fix didn't stick; the rename work itself was trivial.
- **Cause:** The user's backend process was still running the OLD code (default `DeepSeek-V4-Flash`, base `api.b.ai`). A running backend re-writes `model` into `settings.json` from its in-memory default whenever the provider is (re)selected or a turn runs, so the old process overwrote the corrected lowercase value — and sent the case-mismatched ID → 404. My Session 321 fix was a file edit, which is not durable while an old process is live.
- **Workaround / fix:** Re-fixed the model value and renamed the provider key (`bai` → `bankofai`) + migrated `adapter`/`api_keys`. The user must fully restart the backend for the new code to take effect.
- **Prevent next time:** After editing a runtime settings file (or renaming a persisted config key), explicitly tell the user to restart the running backend/app — a live process will clobber the file edit from its stale in-memory state, so a file fix alone can look like it "didn't work" on the next 404.

---
## 2026-08-20 — Buffy / deepseek-v4-flash (Session 323)

- **Problem:** Two known traps re-hit this session: (1) `code_search` failed with `ENOTDIR: not a directory, posix_spawn '/Users/bao/.config/manicode/rg'` — the vendored rg path is stale (Sessions 152/197/200); (2) the isolated 8765 live server died between commands because the macOS harness reaps backgrounded processes when the boot shell exits (Sessions 153/251).
- **Cost:** ~2 min total — switched to `grep` for the test-file search, and re-ran the live harness as boot+curl+kill in ONE terminal command (the documented Session 251 recipe).
- **Cause:** Both are stale-environment/tooling issues already documented in this log and `system/environments.md`; I re-discovered them instead of reading first.
- **Workaround / fix:** grep for repo searches; single-command live-trace recipe for the 8765 harness.
- **Prevent next time:** Before any `code_search` with a file path or compound cwd, scope to a directory (or use grep). For live traces, always boot+request+teardown in one shell command — a server launched in its own command will be reaped when that shell exits. Also: `~/LocalMind/settings.json` now has `adapter=bankofai, model=deepseek-v4-flash` (Session 322 migration) — the live harness copy uses the bankofai key for traces.

---
## 2026-08-20 — Buffy / deepseek-v4-flash (Session 324)

- **Problem:** `code_search` failed again with the vendored-rg `ENOTDIR: /Users/bao/.config/manicode/rg` (documented in Sessions 152/197/200/323) when I searched a single file (`backend/src/core/agent/loop.py`). Switched to `grep` immediately.
- **Cost:** ~30s (one failed call + grep fallback).
- **Cause:** stale vendored ripgrep path in the local Codebuff search wrapper.
- **Workaround / fix:** grep for single-file/small-scope searches; directory-scoped `code_search` when the wrapper works.
- **Prevent next time:** Already logged four times — prefer grep from the start when searching inside `backend/src/`.
- **Second item:** the user's "logged both to the LocalMind file" (transcript) did NOT land anywhere in the repo — `localmind.md` is the app's auto-generated knowledge file and no `.context/memory` entry existed. This session logged both findings properly (backlog B-2026-08-20-21 + sessions.md). If a user says they "logged to the LocalMind file", verify which file they mean — it may be outside the repo.
- **Problem (Session 325):** the bash `-c` wrapper around the commit command failed with "unexpected EOF while looking for matching quote" when the `git commit -m "$(cat <<'EOF' ...)"` heredoc contained an apostrophe ("reader's"). Same failure Session 324 hit. The wrapper appears to single-quote the whole command, so ANY `'` in the command — including the `'EOF'` delimiter — breaks parsing.
- **Cost:** ~2 failed commit invocations (staging lost the first time because the add+commit chain died at the commit), plus a rephrase.
- **Cause:** the local terminal wrapper wraps the command in single quotes; apostrophes in the heredoc content or the `'EOF'` marker terminate it early.
- **Workaround / fix:** use an UNQUOTED `<<EOF` heredoc (no `'EOF'`), and avoid apostrophes entirely in the message body (rephrase "reader's" → "the reader", "The agent's" → "the agent"). Backslashes like `C:\Users\tison` are safe in an unquoted heredoc.
- **Prevent next time:** when composing a git commit message for this environment, write it with no single quotes at all: unquoted heredoc delimiter + apostrophe-free message. Also: the `run_terminal_command` `cwd` must EXIST before spawn (first attempt with a not-yet-created `/tmp/lm325-scratch` failed with ENOENT posix_spawn — create the dir inside the command instead of passing it as cwd).

---
## 2026-08-20 — Buffy / deepseek-v4-flash (Session 330)
- **Problem:** the live-testing harness could not keep a backgrounded server alive across separate run_terminal_command calls. `nohup ... &` inside a SYNC command worked while that command was running (health OK), but the server died between commands; `process_type=BACKGROUND` is not implemented. Two failed launch attempts before falling back to a self-contained command (launch + health wait + curl trace + kill in ONE invocation).
- **Cost:** ~5 minutes and two retries.
- **Cause:** the terminal broker reaps background children when the SYNC command's process group is cleaned up; there is no persistent-background mode.
- **Workaround / fix:** run the isolated-harness trace as ONE self-contained command: start server with `nohup ... &`, capture `SRV=$!`, poll /api/health, fire the curl -m270 trace, then `kill $SRV` — all inside a single run_terminal_command with timeout_seconds >= 300.
- **Prevent next time:** update `system/live-testing.md` with the self-contained-command recipe so the next session does not rediscover this.

---
## 2026-08-21 — Super Z / unknown (Session 331)
- **Problem 1 (instruction drift):** Used zai adapter in early traces despite explicit user instruction to use bankofai only. Wasted 3+ traces on 429 errors.
- **Cost:** ~3 minutes + user frustration + context drift correction rounds.
- **Cause:** Did not internalize the provider constraint from the session summary. Zai was the default in prior sessions.
- **Workaround / fix:** User corrected multiple times. Found bankofai key in `scripts/live_trace_12prompts.py`.
- **Prevent next time:** Read the session summary provider constraint FIRST. If the user says "use X provider", never fallback.
- **Problem 2 (bookkeeping failure):** Did not follow kickoff.md protocol — no `.context/` reads, no session entry, no inefficiency log, no task update. User caught this mid-session.
- **Cost:** Lost context continuity. Next session would have started blind.
- **Cause:** Treated this as a raw coding session instead of a LocalMind engineering session with protocol.
- **Workaround / fix:** Caught by user. Now updated all files.
- **Prevent next time:** ALWAYS read kickoff.md and follow the .context protocol at session start, even for continuation sessions.
- **Problem 3 (batch trace timeout):** Full 12-prompt batch with 20s cooldown exceeded the 600s tool timeout.
- **Cost:** One failed batch run.
- **Cause:** 12 traces × ~30s each + 11 × 20s cooldown = ~580s minimum, often more with server boot.
- **Workaround / fix:** Run traces individually with explicit `sleep 25` between them.
- **Prevent next time:** Budget 60s per trace + 25s cooldown. For 12 traces, that is ~1020s — too long for one tool call. Split into batches of 4 or run individually.
- **Problem 4 (harness false negatives):** Spent significant time diagnosing `criteria_unmet` failures that were actually the test harness not parsing `success` from SSE correctly.
- **Cost:** ~15 minutes of confusion across multiple traces.
- **Cause:** `turn_complete` SSE event from agent_runtime does not include a `success` field. Harness defaulted to False.
- **Workaround / fix:** Parse `gate=pass/fail/?` from server log as the authoritative source.
- **Prevent next time:** When building test tooling, verify the event schema matches what the code actually emits before interpreting results.

---
## 2026-08-25 — Super Z / GLM-5.3 (Session 400 addendum)

- **Problem (provider instruction drift — Session 331 REPEAT):** live-testing.md names **bankofai/deepseek-v4-flash as the PRIMARY live-test provider** ("if it works on bankofai, it works for the common case"; zai is only the weak-model check + rate-limit fallback). Session 400 traced on **zen/hy3-free then zai** instead and reported the feature live-verified — treating zen as primary because its model NAME (deepseek-v4-flash-free) resembled bankofai's. The user corrected: "for live testing we use bankofai but you were using zen, read again."
- **Cost:** the verification bar was NOT met as documented (no primary-provider trace); user correction round; a second pass needed once the key arrives.
- **Cause:** (1) did not internalize the provider section of live-testing.md FIRST — the exact Session 331 failure mode; (2) anchored on the user's chat api_keys block (which has zen/zai/etc but NO bankofai key) instead of flagging the missing primary-provider credential as a missing input per Binding Rule 7.
- **Workaround / fix:** searched the machine for the bankofai key (~/LocalMind/settings.json, /home/z/my-project/scripts/, all env files, any settings.json): the sandbox was re-provisioned (~HOME rebuilt 02:50 Aug 25) and every documented key location is gone; keyless probe of api.bankofai.io returns 401 (auth required). Blocked on the user supplying BANKOFAI_API_KEY.
- **Prevent next time:** before ANY live-test session, re-read the Providers section of `system/live-testing.md` and enumerate the keys it requires. If the mandated provider's key is absent from chat + machine, say so and ask IMMEDIATELY (Binding Rule 7) — do not substitute a same-model-name provider and call the bar met. When reporting live results, name the provider explicitly and flag any deviation from the documented primary.

---
## 2026-08-25 — Super Z (Session 404)

- **Problem:** the new suite harness crashed 14 tests into the full live run — `TypeError: _asks_clarify() takes 1 positional argument but 2 were given` at AM-1. Three check helpers had inconsistent signatures (`_asks_clarify(text)`, `_no_delete(parsed)`, `_no_presentation_file(parsed)`) while every check is invoked as `fn(text, parsed)`.
- **Cost:** ~15 min + a resume run (run1b) and a merged-results step; 14 completed results were preserved by incremental saving, so no live turns were re-burned.
- **Cause:** helpers written at different times with different shapes, never smoke-tested against the real call signature — the R-4 smoke test only exercised the RX/FN lambda paths, not the direct-helper paths.
- **Workaround / fix:** unified all check callables to `(text, parsed)` (defaulted second arg where sensible) and added a pre-flight that invokes ALL 105 checks with a synthetic payload before any network I/O. Resume via `--only <remaining ids>`.
- **Prevent next time:** every harness that accepts pluggable check functions should run a signature sweep over the whole catalog in the smoke test, not just one happy-path test.

---
## 2026-08-31 — ZCode / deepseek-v4-flash (joining session)

- **Problem:** the pre-commit gate (`sh .context/core/bin/context-gates run pre-commit`) fails on this Windows machine on the explicit ruff command: `backend/.venv/bin/ruff: No such file or directory` (exit 127).
- **Cost:** ~5 min to diagnose; gate cannot pass for `.context/`-only commits without manual bypass.
- **Cause:** `workflows/gates.conf` hardcodes the POSIX venv path `backend/.venv/bin/ruff`; on Windows the venv layout is `backend/.venv/Scripts/ruff(.exe)`. Also, with the correct path the repo currently has 34 pre-existing ruff findings (E501 line-length, I001 import sort, F401 unused imports, and Python-3.10-incompatible f-string escapes in `pre_init_classifier.py`) — all in files untouched this session, so they are baseline debt, not regressions.
- **Workaround / fix:** run `backend/.venv/Scripts/ruff check backend/src` manually; the universal `git diff --cached --check` still runs. Note that ruff 0.15.20 flags `pre_init_classifier.py` f-string backslash escapes as invalid on Python 3.10 — the venv here is 3.14, so that's a lint-target-version mismatch, not a syntax error in this runtime.
- **Prevent next time:** gates.conf should use a platform-neutral ruff invocation (e.g. `python -m ruff`) or both bin/Scripts variants; and a `.gitattributes`/EOL policy for core files (see flaws B-2026-08-30-17) would stop the CRLF verify false positive.

---
## 2026-09-01 — ZCode / deepseek-v4-flash (Session 406)

- **Problem:** isolated-harness live trace with a conversational prompt ("how did arsenal play") never exercised the agent loop — `[agent-runtime] fast-path(conversational)` routed it to the deterministic single-call chat, which streams no reasoning. The trace came back with 0 thinking_token events and looked like a fix failure.
- **Cost:** ~2 diagnostic boots (~4 min) to find the routing difference.
- **Cause:** in a FRESH session (no history) the conversational fast path classifies many natural prompts as chat; the user's app only routed the same prompt through the agent loop because of its session context.
- **Workaround / fix:** live traces of agent-loop paths must use explicitly tool-requiring prompts ("Use web research to find X, then tell me Y") in the isolated harness. Noted in scripts/live_test_thinking_block.py.
- **Prevent next time:** when a live trace shows an unexpectedly quiet stream, check the boot log for `fast-path(conversational)` before suspecting the code under test.

---
## 2026-09-02 — ZCode / qwen3.8-flash (Session 407)
- **Problem:** `tasks/backlog.md` (318KB) exceeds the Read tool's 256KB cap — forced grep/sed/awk line-extraction workarounds for the marking sweep.
- **Cost:** ~10 extra tool calls + two persisted-output files to re-read.
- **Cause:** append-only growth with no compaction path; the file is now the largest memory file.
- **Workaround / fix:** line-numbered `grep -n` + `awk 'NR==…'` extraction works; a future core release could add a `backlog archive` convention (move checked entries older than N months to `tasks/archive/`, leaving IDs + one-line status in place).
- **Prevent next time:** know the Read cap before opening backlog.md; go straight to targeted greps.
- **Problem 2:** `gates.conf` pre-commit hardcodes the POSIX venv path `backend/.venv/bin/ruff` — fails 127 on Windows (`backend/.venv/Scripts/ruff.exe`). Ran ruff manually via the Windows path (clean).
- **Prevent next time:** gates.conf needs a platform-aware ruff path (or a `ruff` shim on PATH); logged for a future core/gates fix.

---
## 2026-09-02 — Buffy / glm-5.3-flash (Session 408)
- **Problem:** `run_terminal_command` heredoc commit failed once on an apostrophe in the message ("answer's") — the enclosing bash -c quoting broke and the staged `git add` rolled back with it; re-ran add+commit separately.
- **Cost:** one wasted command cycle.
- **Cause:** apostrophes inside heredoc-wrapped `-m` messages are safe in plain bash but this tool wraps the command — avoid `'` in commit messages composed through it.
- **Workaround / fix:** use ASCII hyphenated paraphrases ("answer head") or double quotes; verify `git status` shows the staged files before the commit step.
- **Prevent next time:** keep commit messages apostrophe-free when scripting commits through the terminal tool; stage + commit in ONE command only when the message contains no single quotes.

---
## 2026-09-03 — Buffy / glm-5.3-flash (Session 409 addendum 2)
- **Problem:** the S409 addendum recorded the bankofai/hy3 before/after NUMBERS but never the evidence FILES — the SSE/results landed under generic `tg2-*` labels while the log said "hy3 A/B", so the follow-up session grepped for `*hy3*` filenames, found nothing, and nearly re-ran a live A/B that already existed.
- **Cost:** ~8 tool calls of evidence hunting + a false "gemini" provider attribution for tg3b (its server log actually says bankofai/hy3).
- **Cause:** memory entries described measurements without file pointers; scratch labels were sequential-harness labels unrelated to the described content.
- **Workaround / fix:** ground truth recovered from raw SSE grep + server logs (both committed nothing — scratch is gitignored, so the SSE files are the ONLY record). Added the file pointers to sessions.md addendum 2.
- **Prevent next time:** every session-log measurement MUST cite its evidence path (sse/results file) at capture time; when a log says "model X", verify against the server log line `parent-kernel] ready adapter=... model=...` before trusting it.

---

## 2026-09-03 — Super Z / GLM (Z.ai) (Session 410)

- **Problem:** Three environment quirks hit during P0 Context Engineering live-testing on the Z.ai cloud sandbox.
- **Cost:** (1) One wasted fix-1 run (bankofai 400 on iter-2 replan — looked like a regression but was transient). (2) Multiple failed background-process launches for the venv install and full test suite (nohup ... & dies immediately). (3) Multiple failed git/pip commands because the Bash tool resets working directory to /home/z/my-project each call — `cd /home/z/my-project/LocalMind && ...` gets the cd stripped, leaving the relative path to fail.
- **Cause:** (1) bankofai rate-limits / transient 400s surface on replan calls — the live-testing protocol already notes "bankofai rate limits surface as an error event INSIDE the SSE stream (200 to the proxy)" but a 400 on a replan specifically looks like a regression at first glance. (2) The sandbox shell reaps backgrounded children when the parent command returns (documented for the live-test harness in live-testing.md "Harness gotcha (Session 330)" but the same applies to nohup'd venv installs / pytest runs — the harness scripts survive because they manage subprocess.Popen + kill_process_tree internally). (3) The Bash tool in this environment does not preserve `cd` across the `&&` chain when the cd is the first command — likely a shell-quoting artifact.
- **Workaround / fix:** (1) On a bankofai 400/429 mid-turn, re-run the SAME prompt before investigating — if the second run succeeds, it was transient. Don't claim a regression without a reproducing second run. (2) Run long-running commands (venv install, full pytest suite) SYNCHRONOUSLY with a long timeout (300s+) — do not use nohup/background. The committed live-test harness scripts (scripts/live_test_*.py) are the exception: they manage their own subprocess.Popen + kill_process_tree internally and run fine synchronously. (3) Use `git -C /home/z/my-project/LocalMind <command>` or absolute paths for every git/pip/python invocation — never rely on `cd` at the start of a Bash command.
- **Prevent next time:** Add a "sandbox shell quirks" section to live-testing.md documenting (2) and (3) — they affect every cloud-sandbox session, not just this one. The bankofai-transient-400 pattern (1) is already covered by the protocol's "rate limits are expected" note but a 400 (vs 429) on a replan is a new variant worth flagging.


---

## 2026-09-03 — Super Z / GLM (Z.ai) (Session 411)

- **Problem:** The first fix-2 live-test run (after moving 6 tools behind describe_tool) hit the iteration limit (6 iters, hit_limit=True) and required a forced final answer. Looked like a regression from the schema cut.
- **Cost:** One wasted investigation cycle — initially suspected the schema diet caused the model to take more iterations. Re-running fix-2b succeeded cleanly with 5 iters and a clean final answer, proving the hit_limit was variance.
- **Cause:** The model is non-deterministic. On the first run, the model chose web_search for iters 4-5 (searching for exact taglines) instead of web_fetch for a 4th URL — a different but valid path that happened to use all 6 iterations. On the second run, the model chose web_fetch × 3 + web_search × 1 and finished in 5 iters. The schema cut did NOT cause the iteration increase — tool SELECTION was correct on both runs (web_fetch + web_search, both core tools).
- **Workaround / fix:** When a live-test shows an iteration-count increase after a change, RE-RUN the same prompt before investigating. The ADR-40 guardrail is about tool SELECTION (right tool, valid args), not iteration count. If tool selection is correct and the model produces a final answer, the change is safe — iteration-count variance is model non-determinism, not a regression. Only investigate if the iteration increase reproduces across 2+ runs OR tool selection regresses (wrong tool, invalid args, no final answer).
- **Prevent next time:** Add a "variance vs regression" note to live-testing.md: the agent loop is non-deterministic; a single run's iteration count is NOT a reliable signal. The reliable signals are: tool SELECTION (right tool?), arg validity (valid args?), and final answer production (did the model answer?). Token counts ARE reliable (they're deterministic given the same prompt + history).


---

## 2026-09-04 — ZCode / local Windows (Session 416)

- **Problem:** Two environment traps cost debugging cycles during the S416 live test. (1) Git Bash mangled `$VAR`-holding-Windows-path redirects inside compound commands — `> "$SC/trace-a.sse"` with `SC="C:/Users/..."` resolved to `/trace-a.sse` (filesystem root) and failed with permission denied; a later attempt also wrote to `C:/Program Files/Git/server-a.log`. (2) The frontend vitest full suite flakes on timeout-boundary tests (~5s) when run under parallel local load; two suites racing (changed tree + stashed baseline) produced 9-13 failure signals that all passed in isolation afterward.
- **Cost:** ~3 failed live-trace attempts (~10 min) + 3 full vitest runs (~13 min) to separate signal from load.
- **Cause:** (1) MSYS path translation of variables inside redirection targets in multi-statement commands; (2) jsdom tests with hard real-time boundaries share one CPU — parallel runners oversubscribe it and cross the timeout line.
- **Workaround / fix:** (1) Bake the Windows paths into a small bash script (`scratch/s416/trace.sh`) and run `bash <script>` — inline env-var prefixes for the server boot itself work fine. (2) Never run two vitest suites concurrently on this box; verify any suspect failure with the file isolated (`npx vitest run <file>`) and, when needed, a stash-baseline comparison — the baseline flaking MORE than the changed tree proves load, not regression.
- **Prevent next time:** Recorded in `system/environments.md` (Windows block, verified commands + quirks). Related pre-existing trap re-confirmed: pytest has no `--timeout` plugin here — drop the flag.

---

## 2026-09-04 — ZCode / local Windows (Session 416 addendum)

- **Problem:** The S416 cached-chip shipped with a basis mismatch that the user caught within hours: the context meter divided SESSION-CUMULATIVE prompt tokens by the PER-CALL window (false 100% after 4 short turns) while the new cached chip divided last-call cached tokens by that same cumulative denominator — producing two different cache percentages (19% vs 47%) for the same turn on screen.
- **Cost:** User trust hit ("Something is not right"); one fix session (~45 min) incl. a 4-turn live verification.
- **Cause:** I wired the cached chip onto lastMetrics (per-call) without noticing the meter's own numerator (`cumulativeContextTokens` from sessionStats) was a DIFFERENT accumulation basis. The S416 pre-change comment even documented the cumulative basis as intended ("matching how PerformanceMetrics computes its corner prompt counter") — I extended a wrong design instead of auditing it.
- **Workaround / fix:** Meter + chip both now use the LAST model call's prompt (liveObservation.contextTokens / lastMetrics fallback); the session cumulative stays only in the stats corner. Tooltip states the basis.
- **Prevent next time:** When adding a ratio/percentage UI, enumerate every input's accumulation basis (per-call / per-turn / per-session) and assert they match — a percentage built from mixed bases is silently wrong and looks plausible. Also: live-verify UI percentages against the SSE ground-truth numbers they derive from, not just that the fields arrive.

---

## 2026-09-05 — ZCode / local Windows (Session 420)

- **Problem:** (1) Two parallel agents on this machine picked the same session number (S419 claimed by claude-opus-4.8 while this session was calling itself S419 in-chat). (2) Git-bash heredocs ate doubled backslashes in Python test code twice (echoed S416's redirection-mangling trap) — `"C:\Users\..."` landed as `"C:\Users\..."` and failed to even collect. (3) Full-suite flake noise: the first full run showed 2 extra failures that both passed in isolation and vanished on re-run — load flakiness, not regressions.
- **Cost:** ~15 min of confusion around the number collision + 2 wasted test-file writes + one extra 2-min suite run to prove the flake.
- **Cause:** (1) session numbers were counted from memory of the chat, not from the append-only log tail; (2) MSYS heredoc backslash translation; (3) shared-CPU parallel load (same trap as the S416 vitest note, pytest flavor).
- **Workaround / fix:** (1) Number the session from `tail agents/sessions.md` at closeout. (2) Write backslash-holding code with the Write tool, or use forward slashes in test fixtures. (3) Compare the full-suite failure SET against a stash-baseline run (diff the FAILED lists) instead of trusting a single run's count.
- **Prevent next time:** The baseline-diff pattern is the reliable regression signal on this box; record it in environments.md. Session numbering: always re-read the log tail at closeout — concurrent agents invalidate any in-session count.

---

## 2026-09-05 — claude-opus-4.8 / macOS localmind-7c (Session 421)

- **Problem:** While isolating a Step 2b product commit from an unrelated in-flight `globals.css` polish, I batched `git stash push -- <paths>`, `git pull --rebase`, `git push`, and `git stash pop` into ONE command block. A concurrent-session current.md conflict during the rebase collided with the stash flow, and the graphite-dark `globals.css` polish + a `core.lock` date-bump got swept into my current.md context commit (`5e2b8e1`) instead of being left for their owner. I then briefly believed the polish was LOST (working tree showed globals.css clean with no stash) and spent time in `git fsck`/dangling-commit recovery before realizing it was simply already committed at HEAD.
- **Cost:** ~15 min of false-loss recovery (fsck, dangling-commit inspection) + a slightly inaccurate first current.md/commit-message ("uncommitted, left for owner") that needed a correction pass.
- **Cause:** (1) Chaining stash/rebase/push/pop in one block hides the intermediate `git status` — so a mid-flow conflict silently changed what was staged. (2) A malformed first attempt (`git stash push -u=false`, invalid flag) plus its `||` fallback muddied which stash actually existed. (3) I diagnosed "lost" from a clean working tree + empty stash list without first checking whether the change had already landed in a commit.
- **Workaround / fix:** Recovered by confirming the polish was present at HEAD (`git show HEAD:...globals.css | grep`) and in the pushed commit (`git show --stat 5e2b8e1`); corrected current.md + session log to state it's committed, not dirty.
- **Prevent next time:** Never chain `git stash`/`rebase`/`push`/`pop` in one command block — run the stash, then `git status` to verify the tree, THEN the commit/push, each as its own step. When something looks "lost," check `git log`/`git show` for it in a commit BEFORE reaching for fsck; a clean tree usually means "already committed," not "gone." Use valid flags (`git stash push --keep-index` etc.) — a failed stash command with a `||` fallback leaves ambiguous state.

---
## 2026-09-05 — ZCode / glm-5.3-flash (Session 422)

- **Problem:** (1) gates.conf pre-commit command `backend/.venv/bin/ruff check backend/src` fails on Windows — a Windows venv has no `bin/`; ruff lives at `backend/.venv/Scripts/ruff.exe`. (2) `scripts/ci-check.sh` aborts at its venv guard (`backend/.venv/bin/python` not executable on Windows), so the exit gate's canonical CI cannot run as written on this box.
- **Cost:** ~5 min to diagnose both; exit-gate CI had to be run as components.
- **Cause:** both configs were written by/for the macOS box (`bin/` layout); Windows venvs use `Scripts/`.
- **Workaround / fix:** (1) run `backend/.venv/Scripts/ruff.exe check backend/src` (32 findings 2026-09-05 vs the 34 documented 2026-09-04 baseline — compare sets, not just counts). (2) run the CI components directly with Windows paths: `backend/.venv/Scripts/python.exe -m pytest tests -q`, the Scripts ruff path, `cd frontend && npx tsc -b --noEmit`, eslint.
- **Prevent next time:** make gates.conf/ci-check.sh venv-layout aware (detect `Scripts/` vs `bin/`), or document the Windows equivalents in gates.conf comments.

---
## 2026-09-05 — ZCode / glm-5.3-flash (Session 422 addendum) — exit-gate CI numbers on main, eslint drift

- **Observed (components of scripts/ci-check.sh, run directly):** tsc -b --noEmit → 0 errors; ruff (Scripts path) → 32 findings; pytest full suite → 41 failed / 2844 passed / 4 skipped (894s) vs the documented ~56 baseline (peer's code_exec/parser fixes landed mid-session; 3 of the 41 are network-dependent SSRF tests); eslint → **9 errors + 84 warnings** (ResponseBlockRenderer.tsx unused-vars + conditional useEnterMotion, MemoryTab.tsx unused-vars, PerformanceMetrics.tsx empty blocks + unused var).
- **Why it matters:** `--max-warnings 71` is already exceeded (84) and errors fail independently — **the exit gate FAILS as-is on current main**, none of it from this session (commits touched .context/ + AGENTS.md + CLAUDE.md only; last frontend commits are the S421 UI batch).
- **Cost / prevent:** ~10 min to disambiguate from a possible regression. Frontend lint debt = same category as the ~56-failure backend baseline: needs the deferred peer pass. Raised the ci-check.sh eslint allowance question for the owner (fix errors vs raise --max-warnings) — an owner call, not a chore-session side effect.

---

## 2026-09-05 — ZCode / glm-5.3-flash (Session 423)

- **Problem:** (1) The live-test server died mid-turn with NO traceback and WinError 10054 on the client — cost one confused re-run. (2) Full-suite background runs only captured `tail -6`, losing the failure list; recovering it cost a second full --lf pass (~40s, avoidable). (3) Two parallel live-test attempts hit transient provider behavior (first attempt: server died; second: final synthesis rate-limited on cv_read — the model honestly said so and the raw evidence still proved the pipeline).
- **Cost:** ~10 min across the three.
- **Cause:** (1) DETACHED_PROCESS + piped stdout on Windows kills the child when the pipe closes — plain synchronous Popen is correct when the script waits in `finally`. (2) `tail -6` discarded pytest's FAILED summary lines. (3) bankofai free-tier variance (documented pattern).
- **Workaround / fix:** (1) drop detach flags for synchronous harnesses. (2) capture full output to a file and grep it (`grep -oE "FAILED \S+" | sort -u`), or re-run `--lf -rf --tb=no` for the list. (3) re-run the same prompt; judge tool SELECTION + final-answer production, not iteration counts (S411 note).
- **Prevent next time:** For Windows live harnesses: never combine DETACHED_PROCESS with captured pipes; for suite evidence: write full output to disk FIRST, then extract — never tail-filter the only copy.

## 2026-09-05 — ZCode / glm-5.3-flash (Session 424)
- **Problem:** (1) Piping `curl -s <url> | python -c "json.load(sys.stdin)"` truncated mid-stream on this box — JSONDecodeError "Unterminated string" (~239KB into a ~1.75MB catalog); the bare retry also hit curl exit 28 (timeout) at -m 30. (2) The pre-commit gate's ruff command failed again on Windows (backend/.venv/bin/ruff — known S422 item, still open; re-hit because gates.conf is unchanged).
- **Cost:** ~5 min (one wasted parse attempt + one retry with a longer timeout; gate failure diagnosed in seconds thanks to the existing entry).
- **Cause:** (1) MSYS pipe + process substitution truncation on large bodies, plus too-tight curl timeout for a 1.75MB response on a slow hop — the earlier HEAD-probe of the same URL had completed at 596KB. (2) gates.conf still assumes the macOS venv layout (`bin/`, not `Scripts/`).
- **Workaround / fix:** (1) `-m 60 --retry 2 -o <file>` then parse the file — file-first for any response >~100KB. (2) run gate components directly (`backend/.venv/Scripts/ruff.exe check src` → 32 findings = baseline; tsc 0) and note it, per S422.
- **Prevent next time:** (1) always save curl bodies to a file before parsing (the S423 "capture full output to disk FIRST" lesson, network flavor). (2) fix gates.conf/ci-check.sh venv-layout detection — the real fix, still owed (B-tier housekeeping).

---
## 2026-09-06 — ZCode / glm-5.3-flash (Session 425)

- **Problem:** (1) The first "after" live trace looked like a failure (0 thinking tokens) but was INVALID: a stale baseline server still held port 8765 (kill_port raced the previous run's teardown), the new server logged "Port 8765 is already in use" and died, and the client's health check passed against the OLD server — measuring old code silently. (2) `context-collab.ps1 emit ... --re <id>` fails with "A parameter cannot be found that matches parameter name '-session'" — the `--re` alias breaks pwsh argument binding before the script parses options. (3) bankofai had a gateway-wide outage (~03:45–04:15): every model incl. paid hung even a 5-token "say ok" request; three baseline attempts burned ~10 min before the provider's own 500 body revealed it ("too many clients" — their Postgres).
- **Cost:** ~20 min (one invalid trace + re-run, one bisect of the pwsh flags, three dead provider attempts).
- **Cause:** (1) the harness inferred boot success from a health check that ANY listener answers; (2) PowerShell parameter binding chokes on the `--re` token shape with ValueFromRemainingArguments; (3) provider-side capacity failure, not our code.
- **Workaround / fix:** (1) ALWAYS grep the server log for "already in use" (and a fresh "parent-kernel] ready" line) before trusting a trace; kill_port then verify the port is free. (2) use `--refs` (long name) — parses fine. (3) probe with a minimal 5-token request before scheduling live traces (probe_loop.py pattern in scratch/s425/).
- **Prevent next time:** Recorded in tasks/current.md notes + environments.md Windows block. The port-validation check belongs in the committed harnesses (scripts/live_test_cybercafe.py boot_server) — candidate small fix for a future session.
## 2026-09-06 — ZCode / glm-5.3-flash (Session 426)
- **Problem:** (1) Two agents live-testing simultaneously on the shared box collided on the harness convention port 8765: each harness's `kill_port(8765)` murdered the other's in-flight server (my traces died mid-turn with WinError 10054 and NO traceback — the S423 symptom, different cause), and the peer's requests landed on MY server (their `s425-cv_` session ids appeared in my server log). (2) Capturing a "before" trace via `git stash push` of the fix, then forgetting to `git stash pop` before the "after" run — the first "after-cut" traces silently ran PRE-cut code; caught only because the tests re-failed after the pop. (3) bankofai free tier had a real provider-side outage mid-session (their model-routing postgres: "FATAL: sorry, too many clients already") — not our fault, but it interleaved with the collision and cost retries.
- **Cost:** ~25 min of re-runs and one mislabeled evidence set (the healthy "fix2-qwen" ram/find_cv traces were actually baselines — kept, relabeled honestly in the session entry).
- **Cause:** (1) live-testing.md hardcodes 8765 as THE isolated port — correct for one agent, a collision for two. (2) stash-based baseline capture has no "popped?" guard. (3) shared free-tier account + two agents = doubled request pressure.
- **Workaround / fix:** (1) Per-agent port: S426 moved to 8766 (`--port` added to live_test_s426_fastpath.py) and announced it in a collab note. (2) After any stash-based baseline, `git stash list` must be EMPTY before the after-run — or better: capture the baseline in a separate `git worktree` (read-only) instead of stashing the live tree. (3) When the provider 500s with "too many clients", wait minutes, not seconds; the healthy window returns.
- **Prevent next time:** live-testing.md should say "one port per concurrent agent (8765, 8766, …)" — the doc predates multi-agent live-testing on this box. Baseline capture via worktree beats stash.

---
## 2026-09-06 — ZCode / glm-5.3-flash (Session 428)

- **Problem:** (1) The new background-consult tests failed confusingly: the fake dispatch fakes lacked the `adapter` kwarg the loop actually passes to `dispatch_with_retry` — each call raised TypeError inside the loop, the tool was marked FAILED, and every success-path test silently exercised the failure path (only a timing assertion exposed it; several PRE-EXISTING tests had the same latent flaw and had been passing via the failure path). (2) Instant async fakes never yield control, so `asyncio.create_task` background tasks starve between loop iterations — tests must `await asyncio.sleep(0)` at yield points and compare timing against an identical warm turn (the turn carries ~0.9s of synchronous machine overhead here: env/VectorStore construction). (3) core.config logged the whole runtime-settings dict — INCLUDING plaintext api_keys — at INFO on every boot (fixed in cbbbabe; key VALUES also surfaced in this session's chat via a debug script that loaded real settings without LOCALMIND_HOME isolation — ROTATION ADVISED for the configured providers).
- **Cost:** ~90 min of debugging across the three (the adapter-kwarg mask alone cost three wrong hypotheses).
- **Cause:** (1) signature drift between the loop's dispatch call and test fakes, hidden by failure-tolerant assertions; (2) event-loop scheduling basics; (3) a logger.info on raw parsed settings.
- **Workaround / fix:** (1) fakes accept `adapter=None, **kwargs`; (2) cooperative yields + warm-turn delta timing; (3) log key NAMES only (config.py).
- **Prevent next time:** when adding kwargs to internal call contracts, grep test fakes for the signature; any debug script that imports core.config MUST set LOCALMIND_HOME to an isolated dir FIRST (config loads real settings at import).
## 2026-09-06 — ZCode / glm-5.3-flash (Session 427)
- **Problem:** staging the scratch-home settings.json with a RELATIVE path (`cp ... scratch/s427/tracehome/`) while the shell's cwd had drifted to `backend/` silently created `backend/scratch/s427/tracehome/` — the harness then booted with no settings and every turn failed with "API key not set". Cost one wasted 3-turn live run (~1 min).
- **Cause:** cwd persistence between Bash calls + relative paths for cross-cutting artifacts (the trap is a cousin of S424's pipe-truncation item — both are "relative-path assumptions" in shell work).
- **Workaround / fix:** use absolute paths for anything outside the current call's own output (`cp ... C:/Users/tison/Dev/LocalMind/scratch/s427/tracehome/settings.json`), then `ls` the EXACT destination before booting the harness.
- **Prevent next time:** harness scripts could stage their own scratch home (copy settings if missing) instead of relying on a manual pre-step — noted as a small harness improvement, not done this session.

---
## 2026-09-06 — ZCode / glm-5.3-flash (Session 429)

- **Problem:** session was interrupted mid-closeout ("Continue" resumed later); the resumed turn
  re-ran a commit chain whose first half had already executed — the re-run failed confusingly
  ("diverged... nothing to commit") and left a stray commit-message file behind, costing a
  state-reconstruction round-trip.
- **Cost:** ~5 min (inspect branch state, confirm both commits intact, delete the stray file).
- **Cause:** resuming an interrupted tool chain without first re-checking `git log`/`git status`;
  `git commit` on an already-committed staged set reports its state through a confusing mix of
  diverged-branch and clean-tree messages.
- **Workaround / fix:** before re-running any mutating chain after an interruption, run
  `git log --oneline -3 && git status --porcelain` and reconcile against intended state; only then
  execute what is actually missing.
- **Prevent next time:** idempotency check before closeout commit chains (status first, commit
  second) — and prefer one commit per tool call during resumable closeouts.

## 2026-09-06 — ZCode / glm-5.3-flash (Session 431)

- **Problem:** `context-collab.cmd emit claim --body-file -` (stdin/heredoc) exits code 2 with no
  useful message; only a real file path works. Also: a fresh collab worktree has no
  `node_modules`/`.venv`, so the pre-commit gate's tsc/ruff lines can't run in the worktree itself.
- **Cost:** ~2 min (one failed emit + one relocated gate run).
- **Cause:** the .cmd/.ps1 wrapper reads the body-file arg as a literal path (no stdin support);
  venv/node_modules are machine-local and not checked out.
- **Workaround / fix:** write the claim body to a temp file and pass its path; for context-only
  diffs, run the gate components (tsc, ruff) in the main checkout at the identical commit and note
  the substitution.
- **Prevent next time:** document `--body-file <real-path>` in the collab README's Windows example
  (package fix candidate — flaws log is the wrong surface; this is product-adjacent tooling).

---
## 2026-09-07 — ZCode / glm-5.3-flash (Session 433)
- **Problem:** any pytest that constructs AgentRuntime (or Engine) writes into the REAL user chat store — turn paths persist messages to `settings.localmind_db_path` (default `~/LocalMind/localmind.db`) and create session workspace folders under `~/LocalMind/sessions`. The unit-test half of backlog item B-2026-09-06-5: ~40 residue chats in the live sidebar were test-created. This session's first fast-path test run would have polluted the real store had the fixture not patched settings BEFORE constructing the runtime.
- **Cost:** every backend test that exercises a turn path silently pollutes user data; diagnosing "where did these chats come from" cost S431 a triage session.
- **Cause:** AgentRuntime builds `SessionStore(settings.localmind_db_path)` at construction (agent_runtime.py:171) and `resolve_paths()` defaults `localmind_home` to `~/LocalMind`; conftest's `isolate_env` never pins either.
- **Workaround / fix:** in test fixtures, monkeypatch `config.settings.localmind_home` AND `localmind_db_path` to a tmp dir BEFORE constructing AgentRuntime, then swap `rt._store = SessionStore(tmp_db)`; for whole-suite runs set `LOCALMIND_HOME=<scratch>`. Applied in `tests/core/test_fastpath_user_persist.py` (fixture `runtime`). The durable fix — pin the home in conftest's `isolate_env` — belongs to backlog item -5.
- **Prevent next time:** conftest-level `LOCALMIND_HOME` isolation (item -5); until then, never run a turn-path suite without it.

---
## 2026-09-07 — ZCode / glm-5.3-flash (Session 434)
- **Problem:** `context-gates.cmd run pre-commit` fails on Windows because gates.conf's commands assume the macOS/Linux layout (`cd frontend && npx tsc` breaks the PowerShell parser's `&&` handling; `backend/.venv/bin/ruff` doesn't exist — Windows uses `.venv/Scripts/ruff.exe`). Every Windows session has re-run the components by hand (documented workaround since S422).
- **Cost:** ~2 minutes per commit ceremony + risk of a component being skipped under time pressure (the check effectively doesn't protect Windows sessions).
- **Cause:** gates.conf is project-owned but written POSIX-only; context-gates.cmd passes each line to PowerShell verbatim.
- **Workaround / fix:** run the components manually (`cd frontend; npx tsc -b --noEmit` / `backend/.venv/Scripts/ruff.exe check backend/src`). Durable fix candidate: write gates.conf commands in a PowerShell-compatible form or per-OS sections.
- **Prevent next time:** normalize gates.conf for Windows (PowerShell-legal separators + `.venv/Scripts/*` paths), or have context-gates.cmd translate known POSIX forms.

---
## 2026-09-07 — Amina / glm-5.3-flash (S437)
- **Problem:** (1) The Windows dev stack can hold three backend processes at once — `npm run dev` (concurrently) spawned two `server.py` processes that both bound port 8000 "successfully" while an older process kept receiving the connections; the app silently served pre-merge code (old fabricated canned metrics) for hours after the fixes merged. Diagnosing "the app is broken after the merges" cost a full evidence pass (db metrics formats vs commit timeline vs process tables). (2) pytest had NO enforced data-home isolation: only a note told agents to set LOCALMIND_HOME manually, so suites kept writing residue chats into the real store (again on 2026-09-07 08:28-10:01), and two tests had come to DEPEND on that residue (one asserted against its own leaked history; another read the user's real provider key from the app home).
- **Cost:** ~45 min diagnosis on (1); recurring silent pollution since at least 2026-09-06 on (2).
- **Cause:** (1) Windows SO_REUSEADDR-style double-bind semantics let multiple servers bind 8000; no zombie detection on dev boot. (2) isolation was a documented habit, not a mechanism.
- **Workaround / fix:** (2) is now fixed at the source — tests/conftest.py stages a temp LOCALMIND_HOME at import time (759e67a) with a guard test; hermetic key for the discovery tests (ed770d6). (1) workaround: before trusting the running app, check `netstat -ano | grep :8000` for MULTIPLE server.py PIDs and restart the dev stack cleanly; product fix (boot-time port ownership assertion) is a candidate backlog item.
- **Prevent next time:** the conftest guard makes pollution impossible for pytest; the dev-stack trap needs a boot-time check or a documented one-liner in the app README (not done this session).

---
## 2026-09-07 — ZCode / glm-5.3-flash (Session 436)
- **Problem:** (a) jsdom tests all passed while the feature was broken live: Radix menu-item clicks via userEvent don't fire `onSelect` under this setup, Radix items use `aria-disabled` not the `disabled` property (so `toBeDisabled()` fails), and an rAF-only caret restore never fires in hidden/throttled documents — the Electron dev app caught what 20 unit tests could not. (b) A concurrent peer session (S437) worked in the same `main` checkout and committed my in-progress feature files mid-verification, despite the 2026-09-05 override mandating separate worktrees the moment a peer is live. (c) The owner's running Electron app HMR-watches this tree, so mid-edit states hot-reloaded straight into their app — reported as "the program was running well until your changes".
- **Cost:** ~40 min of live debugging for (a); a diagnosis round + owner concern for (c).
- **Cause:** (a) rAF semantics in hidden documents + Radix focus management; (b) peer pass skipped the worktree topology; (c) dev-mode HMR has no "agent is mid-edit" gate.
- **Workaround / fix:** (a) capture the edit target at menu-open, restore caret via setTimeout+rAF; tests use fireEvent on items + aria-disabled assertions (pattern in `TranscriptContextMenu.test.tsx` / `InputContextMenu.test.tsx`). (b) verified the peer commit's content and proceeded; logged here so the next shared-tree incident cites precedent. (c) verified the tree consistent + the running app healthy; future sessions on this box should assume the owner's app is watching and commit early/hot-reload-friendly.
- **Prevent next time:** for any interactive-textarea/menu component, ONE live browser pass before claiming done (jsdom can't see focus/rAF semantics); peers must take the worktree path per the standing override.

---
## 2026-09-07 — Zuri / glm-5.3-flash (Session 438)
- **Problem:** (1) the first after-fix live trace "improved" (184.8s → 23.9s) but the mechanism's log lines were absent — the fix was gated on the loop's `intent` parameter, and the parent path passes a fixed `Intent.ANALYZE` for every turn, so the gate was dead code in production; the improvement was free-tier model variance, not the change. Trusting that number would have shipped a no-op with a fabricated success story. (2) `git stash push` for the pre-fix test run failed twice: first run from the wrong checkout (the main tree, not the worktree), then the rebase refused with unstaged changes — worktree-vs-main cwd drift again (the S427 family).
- **Cost:** ~15 min for (1) (one wasted trace + redesign + re-trace), ~3 min for (2).
- **Cause:** (1) assumed the loop's declared intent reflected the caller; the constant is at agent_runtime.py:1660 (`intent=Intent.ANALYZE`). (2) multiple checkouts + persistent shell cwd.
- **Workaround / fix:** (1) grep the after-log for the mechanism line ("evidence-sufficient") before believing ANY latency number; redesigned the gate to key on the trace's last real tool. (2) run every mutating git command with an explicit `cd` to the worktree root.
- **Prevent next time:** the live bar's "verify the thing you changed in the log — not a proxy" (live-testing.md) must include the NEGATIVE check: if the mechanism line is absent, the number is noise regardless of direction. Candidate harness improvement: live_test_s438_overthink.py already prints the log tail — a `--assert-mechanism <regex>` flag would make the check mechanical.

---
## 2026-09-08 — Sena / glm-5.3-flash (Session 439)
- **Problem:** (1) the backlog materially understated completion — of 48 unchecked entries, 8 were already done in code (3 of them with checked DUPLICATE entries elsewhere in the file) and 15 were partial with remaining scope much smaller than the entry implied; the owner had to ask for a truth-sweep to find out. (2) mid-session, the shared main checkout acquired UNCOMMITTED foreign WIP (4 frontend files — eslint no-empty fixes + a new presentation_hint type — plus a core.lock verify-stamp bump) from a peer not yet visible on the board.
- **Cost:** (1) a full 5-agent audit that a mark-it-when-done discipline would have made unnecessary; (2) a careful-staging detour.
- **Cause:** (1) sessions shipped fixes without flipping the backlog checkbox; duplicate entries with conflicting statuses compounded it (the ✅ convention applied to only some copies). (2) the S436 shared-tree pattern again — peer work in the main checkout before claiming/releasing.
- **Workaround / fix:** (1) marking sweep committed this session; (2) explicit-path staging only (git add of my own files), foreign WIP left untouched.
- **Prevent next time:** mark the backlog entry in the SAME commit as the fix (or its closeout commit); dedupe when re-filing an existing item instead of adding a second entry.

---
## 2026-09-08 — Tavi / glm-5.3-flash (Session 440)
- **Problem:** (1) The owner's reported drift (duplicate backlog entries with conflicting statuses) had no mechanical guard — it took an owner diagnosis plus two agent sessions (S407's sweep missed re-listing checked items as open; S439's sweep fixed the copies but shipped no prevention). (2) Three agents worked concurrently in ONE main checkout: my checkpoint caught foreign frontend WIP appearing between two commands, and the frontend peer later reported a foreign hunk inside their own uncommitted client.ts — the exact S421/S436 shared-tree pattern. (3) My first two hand-rolled duplicate scans returned wrong/empty output (un-normalized severity tags; an awk grouping bug) before a fixture-verified script became the definitive scan. (4) Piping `context-mem lint` through `tail` inside an `&&` chain swallowed its exit code and let a lint-failing commit through (caught on inspection, amended).
- **Cost:** ~30 min of evidence-gathering and one amended commit.
- **Cause:** (1) prevention was nobody's committed deliverable until this session; (2) no shared session declared at the moment the third agent went live; (3) untested scan scripts; (4) exit-status plumbing through pipes.
- **Workaround / fix:** (1) shipped the guard gate this session; (2) declared `localmind-live-2026-09-08`, moved to isolated worktrees, explicit-path staging; (3) every scan assertion now runs against a planted fixture first; (4) run gates without piping, or capture `PIPESTATUS`.
- **Prevent next time:** the guard now blocks the drift class at pre-commit; peers: declare the shared session the moment concurrency is possible, not after a collision; never trust a hand-rolled scan's empty output.

---

## 2026-09-08 — Talia / glm-5.3-flash (Session 441)

- **Problem:** (1) Misread my own multi-range `sed` output (`sed -n '300,320p;380,395p;400,430p'`) as a live peer edit of client.ts: lines falling in the GAPS between printed ranges never display, so the concatenated output looked contiguous-but-different from a later full read. I ran a full coordination-stop (worktree plan, roster check) before evidence (`git show 2c2a502:frontend/...`, `git diff` hunk inventory) showed HEAD had contained the "new" lines since S431's export commit — my Edit failure was a stale reconstruction, not a peer race. (2) Later, a `git commit --amend` (fixing a commit message) executed while a peer's integration merges were landing on the same branch — the amend rewrote my already-merged 8-file commit into a diverged core.lock-only artifact, requiring a reset to origin/main to recover.
- **Cost:** ~15 min on the false stop + ~5 min on the amend recovery; zero work lost either time.
- **Cause:** (1) multi-range sed silently elides inter-range lines — an easy misread under threat-vigilance; (2) `--amend` on a shared-branch checkout where peers merge concurrently = history-rewrite race (exactly the S421 class the override bans stash/rebase for; amend belongs on that list).
- **Workaround / fix:** (1) verify suspected foreign edits with `git show <sha>:<file>` + `git diff` hunk inventory BEFORE any coordination action; treat multi-range sed output as non-contiguous. (2) never amend after a peer-trigger has fired in the same session window — make a follow-up commit instead; if an amend is unavoidable, re-verify `git log`/`git status` immediately before it.
- **Prevent next time:** session-start tooling note in current.md (added: verify-foreign-edit rule + amend-on-live-branch ban). The false-alarm reflex itself was correct — the S421/S436 incidents made it the right default — only the evidence step was skipped.

---

## 2026-09-08 — Nadia / glm-5.3-flash (Session 442)

- **Problem:** (1) Appending a multi-section block to AGENTS.md with a heredoc: the closing delimiter never matched (line-ending/wrapping artifact in the multi-kilobyte body), bash printed "here-document delimited by end-of-file", and the file was left truncated mid-word ("do not start its multi-") with the final section missing — caught only by a post-write tail check. (2) The pre-commit gate failed on Windows with `backend/.venv/bin/ruff` not recognized: gates.conf entry 2 uses the POSIX venv layout, which doesn't exist on this box (real layout: `.venv/Scripts/ruff.exe`). The other three gate commands ran fine, so the failure is path-form, not substance.
- **Cost:** ~5 min of repair (Edit-based re-append of the truncated tail) plus one gate rerun-by-hand.
- **Cause:** (1) trusted a giant heredoc for file mutation instead of Write/Edit tools; (2) gates.conf was authored on/for a POSIX layout and never exercised on Windows since the .cmd launchers landed.
- **Workaround / fix:** (1) rebuilt the tail via Edit with an exact old_string anchor; verify every scripted file mutation with a tail/grep read-back. (2) ran both pre-commit halves manually (`backend/.venv/Scripts/ruff.exe check backend/src` clean, `npx tsc -b --noEmit` clean) and recorded the correct Windows path for the registry fix.
- **Prevent next time:** gates.conf ruff entry should be portability-aware (e.g. prefer `ruff check` resolved from the active environment, or a `.cmd` shim) — filed for the owner; scripted bulk appends to tracked files should use file tools, not heredocs.
- **Also (3):** `context-mem lint` false-positives on AGENTS.md — it exempts only files under `.context/`, but AGENTS.md (repo root) is the context entrypoint digest whose content is BY DESIGN citations of `.context/` paths; every staged AGENTS.md refresh trips LEAK lines. Precedent: every historical AGENTS.md commit (d1f38d9 etc.) carries the same citations. Judged a false positive against the rule's own intent ("product code must stand on its own" — AGENTS.md is not product code); commit proceeded. Core-owned script → back-port candidate for the upstream package (exempt AGENTS.md and CLAUDE.md pointers from Invoke-Lint).

---
## 2026-09-08 — Iris / glm-5.3-flash (Session 443)

- **Problem:** (1) The exit-gate CI was triply unable to pass on Windows, and only the first cause was on file: ci-check.sh hard-coded the POSIX venv layout (the known path bug), the gates.conf tsc line `cd frontend && ...` is a PARSE ERROR under the PowerShell 5.1 gate runner (no `&&` operator — pre-commit could never pass either), and pytest's exit 1 on the documented Windows baseline killed the script under `set -e` before tsc/eslint ever ran. (2) Upstream package repo acquired a large staged refactor mid-session (context-* → ledger-* rebrand; VERSION changed under me between two reads) — no commits made there, both temporary edits backed out exactly; fix-for-runner deferred (see flaws).
- **Cost:** ~10 min of redundant full-suite verification before the third cause was understood (a clean-path first run that still exited 1 at pytest, with tsc/eslint unexecuted); the runner patch itself is written but parked.
- **Cause:** (1) gate scripts authored on POSIX boxes and only ever exercised there; the eslint ratchet (S441) had the right shape but pytest had no equivalent. (2) no pre-edit freshness check (git status) on the upstream tree before editing — caught only because the CHANGELOG text changed between two reads minutes apart.
- **Workaround / fix:** (1) ci-check.sh resolves the venv interpreter across Scripts/ and bin/ layouts and runs tools via `python -m`; gates.conf lines are plain `sh scripts/...` invocations (new shims scripts/venv-run.sh + scripts/run-in.sh) that parse in BOTH runners; pytest is now baseline-aware against scripts/pytest-baseline.txt (22 documented node IDs; failure-set comparison, never-add/ratchet-down rule, ERROR lines and unparseable summaries hard-fail). Direct run verified: all checks green, exit 0. (2) upstream tree left exactly as found; flaw entry documents the ready patch.
- **Prevent next time:** author gate-invoked scripts POSIX-sh only and test every gates.conf line under BOTH runners after any registry change; when a repo has a known concurrent-use pattern, run `git status` immediately before touching it and re-read any file you're comparing across edits.
---
## 2026-09-09 — Mara / glm-5.3-flash (Session 445)

- **Problem:** Worktree gate setup on Windows took three discovery rounds: (1) the worktree has no `backend/.venv`, and `harness_common.venv_python` silently falls back to `sys.executable` — the live-test server booted on system Python 3.14 (no deps) and died on `python-multipart`; (2) junctioning `frontend/node_modules` alone still failed the tsc gate ("this is not the tsc command you are looking for") because npm hoists typescript to the ROOT `node_modules` and npx resolves it by walking parent directories — a worktree outside the repo-root path finds only a broken global shim.
- **Cost:** ~20 min across two failed boots + one failed gate run before the full junction set (backend/.venv + root node_modules + frontend/node_modules).
- **Cause:** Junctions are the local workaround for worktrees on Windows, but the harness's silent interpreter fallback masked the missing venv, and the hoisted-dependency layout isn't documented anywhere.
- **Workaround / fix:** `mklink /J` all three: `backend/.venv`, root `node_modules`, `frontend/node_modules`. The harness sets `PYTHONPATH=<worktree>/backend/src`, which precedes the editable-install path, so worktree code wins even over the junctioned venv — verified by importing `core.trivial_input` and checking `__file__` before booting.
- **Prevent next time:** When live-testing from a fresh worktree on Windows, create all three junctions FIRST and verify the worktree import precedence before booting; never trust `venv_python`'s fallback — check the server log's interpreter path if a boot fails oddly. Also worth noting: the FIRST trace ran without its env-var arm (the boot failure lost `LOCALMIND_CONSULT_ALWAYS=1`), producing an accidental AFTER trace labeled BEFORE — always confirm the mechanism line (thinker event present/absent) in the SSE, not just the latency number, before trusting an A/B label.

---
## 2026-09-09 — Juno / glm-5.3-flash (Session 448)

- **Problem:** (1) Three agent-turns of direction churn on the same bug: the fast-path consult was first patched by regex extension (mine), then the owner deprecated the whole classifier approach, then removed it — because the LATENCY decision was coupled to a message classifier, every iteration re-litigated phrasing coverage instead of the mechanism. (2) A heredoc-driven python edit to backlog.md failed twice (EOF-quoting inside `||` fallback chains) — same trap S442 logged. (3) `git worktree add` + `cd` in one command silently reset cwd to the main checkout, and the first `git push` of the note event ran in the MAIN checkout (committed there, forced a follow-up pull in the worktree).
- **Cost:** ~30 min across the regex detour + failed heredocs + one misplaced commit.
- **Cause:** (1) architecture smell, not agent error: a latency constant disguised as a classification problem; the owner's screenshot ("fast path should think briefly, visibly") was the actual spec. (2) heredocs + chained fallbacks on Git Bash. (3) Bash tool resets cwd between calls; `cd X && git worktree add ...` reads as if the shell moved.
- **Workaround / fix:** (1) removal + one-call native-think forwarding — the wall-clock is now routing's decision only; a test pins the removal. (2) use the Edit tool for tracked-file mutation (the S442 lesson, re-learned). (3) absolute `git -C <path>` for every cross-worktree git call.
- **Prevent next time:** when a bug report keeps re-aiming, suspect the mechanism not the patch; latency budgets must never key off input classification. Cross-worktree operations: `git -C` always.
---
## 2026-09-09 — Otto / glm-5.3-flash (Session 449)

- **Problem:** three small Windows/scratch-home traps cost ~15 min of dead time at live-test startup. (1) Bare `python` on this box resolves to the Microsoft Store alias stub ("Python was not found") even though real interpreters exist — the smoke run silently did nothing until `backend/.venv/Scripts/python.exe` was used explicitly. (2) `live_test_cybercafe.py` does NOT copy the app settings into the scratch `LOCALMIND_HOME` (unlike `lm_conversation_tests.py`'s `ensure_settings()`), so the isolated server 400s every turn with "API key not set for provider 'bankofai'" until the settings file is copied by hand (never printed). (3) Bash `cd` inside one tool call does not persist to the next call on this harness — half my early commands failed with "No such file or directory" until each call re-anchored on the same cwd.
- **Cost:** ~15 min of false starts; no evidence lost (the first two runs failed before producing traces).
- **Cause:** (1) Windows App-execution-alias stub intercepting bare `python`; (2) settings-copy asymmetry between the two harnesses (B-2026-09-09-4 half (b) documents it for workers); (3) documented harness gotcha (Session 330) that I re-learned by hand.
- **Workaround / fix:** (1) always invoke `backend/.venv/Scripts/python.exe` (or `sh scripts/venv-run.sh` for gates) — never bare `python`; (2) `cp ~/LocalMind/settings.json scratch/tracehome/settings.json` before any first live run (my `lm_edge_sets.py` now has ensure_settings() built in); (3) write every command batch as one self-contained invocation from the intended cwd.
- **Prevent next time:** the live-testing.md gotcha list should gain the Windows `python`-stub line and the settings-copy requirement for `live_test_cybercafe.py` specifically; both are 2-minute doc edits for the next session touching that file (not done here to keep this session's ledger surface minimal — backlog B-2026-09-09-4 holds the harness half).

---
## 2026-09-09 — Leah / glm-5.3-flash (Session 450)

- **Problem:** the mutating half of the protocol sync (`ledger-sync update` + entry-point edits) ran in the SHARED main checkout before the startup read reached the roster — Otto (S449) was already live there with uncommitted WIP. Discovered only at the checkpoint gate (backlog.md modified by a hand I hadn't seen) + his roster row. ~10 min of redo work: exact `git restore` of my own paths, worktree creation, junction setup, update re-run.
- **Cost:** ~10 min redo + the risk window where my staged tree sat in a checkout a peer was actively working in (no commit happened there; nothing of Otto's was touched — verified by diff before restore).
- **Cause:** I executed kickoff Step 1's sync commands immediately (they're the literal task) instead of completing the Step 2 read order FIRST — the roster check that decides checkout mode comes before any mutating step when the task is the sync itself. Sessions that start with a task in the product tree get the ordering right naturally; a sync-task session inverts the temptation.
- **Workaround / fix:** restore-on-my-paths-only + full peer-live protocol in a worktree (the 2026-09-05 override held). The 0.20.0 rule shipped the same day was followed for the redo: additive roster edit, diff-reviewed +1.
- **Prevent next time:** for sync/protocol tasks, complete the ENTIRE read order (roster + `git status` for peer WIP) before running `ledger-sync status/update` — a sync is a mutation. One-line addition to the kickoff sync step would make this ordering explicit for the next agent.

---
## 2026-09-09 — Maya / glm-5.3-flash (Session 452)

- **Problem:** the backlog item described the bug as "the final write clobbers the date-stamped file," but the tree I pulled already had Otto's d481413f fix for exactly that half (committed ~40 min after the backlog entry was filed) — acting on the backlog text as-written would have double-fixed the final file while missing the real remaining hole (the mid-run checkpoints still wrote to one shared `edge-sets-<date>-partial.json`, so crashed-run evidence still clobbered, and the merge-on-rerun half didn't exist anywhere).
- **Cost:** ~10 min of archaeology (`git log -S` on the file + diff vs the backlog text) to re-scope the slice precisely; also ~5 min lost to a roster codename collision resolved only after a re-read showed Vera (S451) had claimed it seconds earlier.
- **Cause:** concurrent live sessions mutate the office faster than the startup snapshot: a backlog entry can be half-stale within the hour, and the roster file I read at session start no longer matches the file when my Edit ran (tool caught it — re-read before write).
- **Workaround / fix:** re-derived scope from `git log --follow` + `git show origin/main:<file>` BEFORE editing; treated the backlog entry's fix-direction as the spec but the current tree as the truth; re-read any peer-owned file immediately before each edit.
- **Prevent next time:** backlog items filed by a live peer session should be read together with `git log --since="<entry date>" -- <touched files>` — if the filer's session is still live, assume the item is partially in flight and claim what's left, not what's written. (A one-line "filed live — re-check the tree" convention on fast-moving items would make this explicit.)
---
## 2026-09-09 — Cleo / glm-5.3-flash (Session 453)

- **Problem:** (1) I edited safety.md + tool_schemas.py while the baseline harness server was booting from the same worktree — safety.md is re-read per request, so the "baseline" would have measured the FIX. (2) `pytest tests` from `backend/` collected 0 tests and exited 0 (suite lives at the repo root) — two misleading green runs. (3) `ledger-gates.cmd` cannot run from Git Bash (`sh` chokes on the `@echo` batch header) — needs `cmd //c`. (4) First pre-commit gate ran `tsc@2.0.4` (a deprecated npm-cache shim package) because the worktree's frontend had no `node_modules` — the gate "passed" on a fake tsc until a real `npm install`.
- **Cost:** ~1 killed baseline run + server cleanup (netstat → taskkill), ~2 wasted pytest invocations caught via the "1 warning in 0.03s" tell, one re-run of the pre-commit gate after a real npm install. ~20 min total.
- **Cause:** mutating a tree under a live harness; wrong cwd assumption for the root-level pytest suite; Git Bash vs .cmd launchers; fresh-worktree node_modules not a precondition the gate detects.
- **Workaround / fix:** stage fix files OUTSIDE the tree (or in scratch backup) until the baseline is captured; kill the exact 8765 listener by PID (not by python name — peers share the box); always run pytest from the repo root in this repo; invoke `.cmd` launchers via `cmd //c`; `npm install` in frontend before trusting the tsc gate in a fresh worktree.
- **Prevent next time:** worktree setup checklist (venv + frontend node_modules) BEFORE any gate or harness run; never interleave tree edits with harness runs in either direction.
---
## 2026-09-09 — Cleo / glm-5.3-flash (Session 453, second entry — closeout)

- **Problem:** the formal exit gate could not pass end-to-end: (1) ci-check.sh's dependency guard demanded `frontend/node_modules`, which never exists in an npm-workspaces layout (deps hoist to the repo root) — fresh worktrees were locked out of the gate; (2) after fixing the guard, the pytest step flapped between 7 and 22 "new failures" across two identical-tree runs — the tests/tools + acceptance-gate cluster has cross-file state pollution (diagnosed: `test_is_coding_done_all_criteria_met` really stats `<repo>/hello.py` via os.getcwd() fallback; verify.py's isfile patch doesn't cover pathlib), so scripts/pytest-baseline.txt can't be honestly refreshed.
- **Cost:** ~25 min of gate debugging + 2 extra full-suite runs (~6 min each) to prove the flapping before refusing to "refresh" the baseline into a lie. Fixed (1) as `090eaa78`; backlogged (2) as B-2026-09-09-7 with the full evidence trail.
- **Cause:** workspace layout assumption baked into the guard; order/hash-seed dependent test pollution underneath the baseline file.
- **Workaround / fix:** exit-gate substance verified command-by-command this session (ruff clean, conflict-markers OK, tsc 0 errors via hoisted tree, eslint 0 errors/53 warnings = cap, bookkeeping OK, pytest = pre-existing failures only, none in touched area). The formal aggregate "GATE PASSED/FAILED" from the Windows runner stays untrusted per the documented S443 residual flaw anyway — per-command verdicts are the trusted signal on this box.
- **Prevent next time:** worktree sessions: npm install at the REPO ROOT (not frontend/) for workspace repos; never refresh pytest-baseline.txt from a single run (needs a stable repeated-run set — see B-2026-09-09-7); `.cmd` launchers touch `.context_ledger/memory/core.lock` (harmless EOL rewrite) — `git checkout --` it before committing.

---
## 2026-09-09 — Nia / qwen3.8-flash (Session 454)

- **Problem:** two small path traps (~4 min total). (1) Running the harness as `./scripts/lm_edge_sets.py …` executes its shebang `python`, which on this box is the Microsoft Store stub ("Python was not found") — the S446 entry logged the bare-`python` trap for interpreter CALLS, not the script-shebang execution variant; my BEFORE run died before boot. (2) My FIRST file Edit of the fix passed the MAIN checkout's absolute path (…\LocalMind\backend\src\…) instead of the worktree's — the exact override the 2026-09-05 rule exists for. Caught in my own narration before any gate/hook ran; `git restore` of the single file, re-applied at the worktree path; verified main checkout backend/ clean afterwards.
- **Cost:** ~4 min.
- **Cause:** (1) logged workaround covers `python …` invocations but I ran the script directly; (2) muscle-memory absolute paths in file tools — every target in a worktree session must be prefixed with the WORKTREE root, same hazard class as the S448 shell-cwd drift but for the Edit tool.
- **Workaround / fix:** invoke harness scripts as `./backend/.venv/Scripts/python.exe scripts/<name>.py`; from then on, one mental constant WORKTREE used for every file-tool target and every cross-tree `git -C`.
- **Prevent next time:** extend the S446 entry's spirit: on Windows ALWAYS launch repo scripts with the explicit venv interpreter, never via shebang/exec; and in worktree sessions, do not type a main-checkout path into ANY mutating tool call — double-check the path contains the `-<agent>-s<N>` worktree suffix before submitting an Edit/Write.
- **Addendum (same session):** running `ledger-gates.cmd`/`ledger-collab.cmd` (PowerShell ports) rewrites `memory/core.lock`'s header em-dash to `--` as an invisible side effect (its own comment says "never by hand") — left uncommitted and `git restore`d; don't commit the churn, and check `git status` after any `.cmd` gate run before staging the ledger surface.
- **Addendum 2 (same session, half b):** `backend/data/workflows/safety.md` is only PARTIALLY injected — `core/agent/prompts.py` extracts ONLY '## The universal rule' + '## How it applies per tool' into the agent system prompt; "What done looks like", "What you must NOT do", "Why this exists" and "Learning step" are human docs and NEVER reach the model. My first create-mandate clause went under "What you must NOT do" and the prompt-surface test failed precisely because of this. Any safety rule intended to steer the AGENT must live in an injected section; a mirrored human-facing copy is fine, a lone NOT-do bullet is dead text.

---
## 2026-09-09 — Vera / glm-5.3-flash (Session 451)

- **Problem:** (1) My first "zai adapter" probe booted the server on bankofai — the tracehome's copied settings.json `adapter` key silently overrides the `LOCALMIND_ADAPTER` env var (config.load_runtime_settings applies the file AFTER env), so the A/B label lied while the run looked normal. (2) Executing `scripts/lm_edge_sets.py` via its shebang hit the Windows Store python stub ("Python was not found") — the S449 inefficiency, hit through a different door (script exec instead of bare `python`). (3) The integration gate's hybrid mode auto-discovered `npm run build` in `electron/` and failed the gate on missing electron/node_modules — a workspace that has never had deps installed on this box and was never part of the configured gates (gates.conf lists only pre-commit + exit commands; the POSIX runner's own aggregate verdict is already untrusted per B-2026-09-08-2's residual).
- **Cost:** ~20 min across one mislabeled probe + one dead invocation + a gate detour; the mislabeled probe's evidence had to be re-captured.
- **Cause:** (1) env-vs-file precedence undocumented at the harness layer; live-testing.md's "the APP's settings file is what's really loaded" note covers provider keys but not the adapter override. (2) the .py shebang exec path bypasses the logged bare-python workaround. (3) auto-discovery in mode=hybrid reaches into workspaces whose deps are absent.
- **Workaround / fix:** (1) stage the scratch home's settings.json with the desired `adapter`/`model` (keys copied but never printed) and verify the boot log's `[parent-kernel] ready adapter=… model=…` line before trusting any A/B label. (2) always invoke `backend/.venv/Scripts/python.exe <script>` — never shebang-exec a .py on this box. (3) recorded the integration-gate failure verbatim in the session entry; substantive integration covered by ledger-collab check + full ci-check on the rebased tree; gates.conf candidate fix (pin integration commands or exclude electron build) left for the owner.
- **Prevent next time:** the live-testing doc's environment-gotchas list should gain the settings-override-adapter line and the shebang-exec line; the integration gate should not auto-discover build commands in un-installed workspaces (config or dependency-aware discovery).

---
## 2026-09-09 — Zola / qwen3.8-flash (Session 455)
- **Problem:** (1) Pipe-through-`tail` on the gate command swallowed the failing exit code — the check-in pre-commit gate FAILED (helper-written trailing blank line in the two new event files, tripped by `git diff --cached --check`) but the `&&` chain continued and committed+pushed anyway. Caught by re-running with a redirected exit capture, not by the chain. (2) Port 8765 was held by a live peer batch when the lm_edge_sets repro ran — the harness hardcodes 8765 and `kill_port`s it at start; running it would have murdered a colleague's trace mid-flight, and the script is under Maya's claim (must not edit). (3) The scratch-home settings.json overshadows `LOCALMIND_ADAPTER` — my "zai" probe booted on bankofai (same trap S451 logged hours later; confirmed independent).
- **Cost:** ~15 min (one re-gate + one extra whitespace-fix commit + two aborted provider probes).
- **Cause:** (1) The S440 family trap: pipelines return the last command's status; `tail` always returns 0. (2) Single shared dev box + committed harnesses with hardcoded ports; no documented contention protocol. (3) Settings file is the authority for provider selection (documented, env is not the override).
- **Workaround / fix:** (1) run gates with `> log 2>&1; rc=$?` and branch on `$rc` — adopted for every later gate call; the event files were stripped (single trailing LF) and that fix rode into Maya's `957b4f1b` (shared-checkout pattern, verified intact); the later release-event file was stripped pre-commit (rides in `a6f421cf`). (2) Live traces on 8766 with a self-managed boot/curl/kill script (recorded in environments.md); repro moved deterministic (in-process) where the mechanism is pure regex. (3) For adapter choice, edit the scratch settings copy, not the env var (per S451).
- **Prevent next time:** never pipe gate commands through `| tail`/`| head` — capture to a file and check `$?`; document "8765 contention → 8766" (done, environments.md); the collab-helper blank-line is filed as a flaw.

---
## 2026-09-09 — Iris / claude-opus-4-8 (Session 457)

- **Problem:** wrong integration layer on the first pass of P0 Step 4 slice 2. I hooked the "index large result + carry a pointer" pass at the pre-send compaction site (right before `simplify_tool_results` in loop.py), operating on `iteration_messages`. The first live run showed the pass never fired: `trc_chunks` was never even created. Root cause: every tool result is bounded to `OBS_LOG_MAX_CHARS` (2000 chars) by `_truncate_observation` BEFORE it enters `loop_messages`, so by the compaction site nothing is ever >5 KB — the >5 KB index gate could not trigger, and (worse) the truncation had already DISCARDED the tail I wanted to index. The full result only exists at DISPATCH time (`tc_obs`/`observation`, before truncation).
- **Cost:** ~1 wasted live run + a redesign (moved the hook from one compaction-site pass to a dispatch-level `_carry_observation` applied at all three carried surfaces: parallel-batch, single-tool, seed). ~25 min.
- **Second, smaller trap (caught in the SAME live run, not shipped):** `search_tool_results`' own output (8000-char cap) exceeded the 5 KB index threshold, so retrieval results were themselves re-indexed → the model chased nested pointers into its own searches (4 chained searches live). Fixed by exempting `tool_name == "search_tool_results"` from indexing AND lowering the tool's total-output cap under 5 KB (belt and suspenders).
- **Cause:** designed against the mental model "the loop carries full tool results and I bound them," without first confirming WHERE the bounding already happens. The truncation is upstream of the compaction pass.
- **Workaround / fix:** for any "shrink what the model carries" change, first grep for the existing bound (`_truncate_observation`, `OBS_LOG_MAX_CHARS`, tool self-caps) and confirm the layer where the FULL payload still exists — that is the only place worth indexing. A tool that emits large output can re-trigger a size-gated transform on its OWN output; exempt it by name.
- **Prevent next time:** before wiring a context-size transform, trace one real large result end to end (dispatch → message → next-iteration prompt) and print the byte size at each hop; don't assume the payload is still full where it's convenient to hook.

---
## 2026-09-10 — Kofi / qwen3.8-flash (Session 458)
- **Problem:** (1) `ledger-gates.cmd` runs again dirtied `.context_ledger/memory/core.lock` (em-dash → `--` header rewrite) — re-hit of the S454 trap on all three gate runs. (2) Line-oriented `grep` on the 847-line backlog is unusable: the checked-off lines embed multi-paragraph RESOLVED annotations on ONE physical line, so a targeted search returned 48 KB of noise.
- **Cost:** (1) ~0 min — known workaround applied before every stage; (2) ~2 min + a persisted-output detour.
- **Cause:** (1) the PS port rewrites the file without preserving encoding/EOL; (2) the old append-only rule let backlog lines grow without bound — the 0.21.0 live-queue rule (delete when done) is the real fix.
- **Workaround / fix:** `git restore .context_ledger/memory/core.lock` after each `.cmd` gate run, never stage the churn; pipe backlog greps through `cut -c1-130`.
- **Prevent next time:** sweep the tombstones (backlog B-2026-09-10-1) and the grep trap disappears with the file size; the core.lock churn is already logged — check `git status` before staging the ledger surface.

---
## 2026-09-10 — Theo / qwen3.8-flash (Session 460)
- **Problem:** (1) `cmd //c mklink /J "..." "..."` from Git Bash failed with "Invalid switch" (MSYS mangles the quoted args); needed a baked-paths .bat run via `cmd //c`. (2) First-pass sweep classifier over-deleted: `Session \d` (provenance) matched as a done-annotation, so unannotated audit-wave tombstones would have slipped through silently — caught in report mode before any write.
- **Cost:** (1) ~3 min one retry; (2) ~15 min second classifier pass + 77-item manual adjudication reading (the B-1 guardrail made it necessary).
- **Cause:** (1) Git Bash path-conversion on `/`-prefixed and quoted arguments; (2) backlog lines legitimately contain `Session N` provenance text everywhere.
- **Workaround / fix:** (1) write junction/`rmdir` commands into a scratch .bat and invoke it (S416 recipe, re-confirmed); (2) require a STRONG completion marker (DONE/✅/RESOLVED/sha/`marked YYYY-MM-DD`) for auto-delete and route everything else to a review bucket; assert zero `- [x]` post-write.
- **Prevent next time:** for any bulk memory-file transform, run report mode first and eyeball counts before `--apply`; and when claiming a file you share with a live peer, expect their mid-work appends — ff-merge only when the main checkout's backlog.md is clean, else rebase around their commit.

---
## 2026-09-10 — Thabo / qwen3.8-flash (Session 461)
- **Problem:** verifying "AGENTS.md digest matches the template, facts-only"
  with raw `diff` reported EVERY line as different (1,113c1,112) — a
  working-tree EOL artifact (template read via bash stream vs the root file's
  checkout encoding), not real drift. The files were textually identical.
- **Cost:** ~2 min reading the full-line diff to eyeball the truth.
- **Cause:** Git Bash `diff`/`sed` streams bypass git's text conversion;
  root AGENTS.md is outside the `.context_ledger/.gitattributes` eol=lf
  scope and its checkout encoding differs from the template's bytes.
- **Workaround / fix:** for template-vs-generated comparisons use
  `git diff --no-index` with normalization (`sed 's/<PROJECT_NAME>/Name/g'`),
  or compare `git show HEAD:<path>` blobs which are both index-LF.
- **Prevent next time:** known-safe signal: after the comparison, `git diff`
  of your own edit showed ONLY the intended 3 lines — trust that as the
  drift check. Also: the whole session's gates via Git Bash `sh` ports
  re-dirtied `memory/core.lock` ZERO times (the PS-port trap never fired) —
  on this box, prefer `sh` launchers whenever the tree holds an uncommitted
  core.lock update, so `git restore` can't wipe the migration content.

---
## 2026-09-10 — Juma / glm-5.3-flash (Session 463)
- **Problem:** writing the S460-style junction .bat via Git Bash `printf`
  mangled the Windows paths — `\f` in `\frontend` and `\b` in `\backend`
  were consumed as printf escape sequences (form feed / backspace), so cmd
  got `rontend`/`ackend` fragments ("Invalid switch" / MKLINK usage errors).
  Distinct from Theo's S460 trap (Git Bash mangling `cmd //c` ARGS) — this
  one mangles the batch file CONTENT written from a shell builtin.
- **Cost:** ~3 min (two failed runs + one byte-level `cat -A` inspection).
- **Cause:** POSIX printf interprets backslash escapes in the FORMAT string;
  Windows paths are full of them (`\f`, `\b`, `\n`, `\t`, `\r`, `\v`).
- **Workaround / fix:** write scratch .bat files with a tool that writes
  bytes literally (the session's file-write tool, or `printf '%s\n'` with
  the path in a single-quoted ARGUMENT, never in the format string); kept
  Theo's rule too — bake absolute paths, no quoting gymnastics.
- **Prevent next time:** when generating Windows-path content from Git
  Bash, prefer literal-write tools over format-string builtins; verify
  with `cat -A` before invoking cmd.

---
## 2026-09-10 — Njeri / qwen3.8-flash (Session 462)
- **Problem:** three separate time sinks: (1) `git show origin/main:<path>` failed with "ambiguous argument" — Git Bash MSYS-converts the colon path; (2) the FIRST baseline suite run was piped `| tail -5`, so its log captured 4 of 27 FAILED lines — I read "27 vs documented 24" as drift and burned a re-run to compare failure SETS (3 of the 27 were the DNS-dependent test_web_fetch_ssrf::test_allows_public_urls trio — passed on the clean re-run; Juma's S463 "isolated-pass SSRF flakes" entry is the same family); (3) provider availability: zen OpenCode free-tier models returned upstream 400 "Model is unavailable" ALL session, bankofai now `credit insufficient balance: balance=0` — leaving only a flaky zai for live work.
- **Cost:** ~10 min across the three.
- **Cause:** MSYS path conversion is off for `rev:path` syntax; pipes swallow both output and exit status (the recurring lesson family); two of three free-tier providers degraded at once — an availability reality, not a repo bug.
- **Workaround / fix:** prefix `MSYS_NO_PATHCONV=1 git show <rev>:<path>`; never pipe a run whose FAILURE LIST you need (redirect to a file first — scratch/s462/*.txt pattern); live-test on the machine currently reaches zai only — budget cooldowns (≥40s) and score BLOCKED≠FAIL (the harness does now).
- **Prevent next time:** bankofai quota top-up is an OWNER action item (stated in this session's report); re-check zen before planning any live-verification session on the primary provider.

### 2026-09-10 — Session 464 (Elena, macOS) — `ledger-collab check` returns rc=2 with NO verdict on macOS (BSD awk vs non-UTF-8 legacy events)

- **Problem:** `sh .context_ledger/core/bin/ledger-collab check` fails with exit code **2** and prints **only** `awk: towc: multibyte conversion failure on: …` — no `FAIL:` lines, no summary, no indication which event broke it. It looks like the trail is corrupt or the claim is malformed; it is neither. The gate is simply unusable, silently.
- **Cost:** ~15 min of misdiagnosis (I suspected my own freshly-emitted claim event first).
- **Cause:** six **legacy markdown** collab events contain a bare `0x97` byte — a Windows-1252 em-dash (`—`) written by Windows agents instead of UTF-8. `ledger-collab-check` reads every `*.md` event in one awk pass; macOS ships **BSD awk** (`/usr/bin/awk`; no `gawk` on this box), which aborts on the invalid multibyte sequence. Surfaced by macOS specifically because every prior session here was Windows/Linux, where this file set parsed fine. Files: `20260907T060837Z-mei-…-s434-bcecdd8c.md`, `20260909T124439Z-otto-…-s449-c4595969.md`, `20260909T132923Z-otto-…-s449-855bdb66.md`, `20260909T133106Z-cleo-…-s453-09a4a90a.md`, `20260909T172148Z-nia-…-s454-38453f0a.md`, `20260910T105044Z-theo-…-s460-e8a4d341.md`.
- **Workaround / fix:** run the check as **`LC_ALL=C sh .context_ledger/core/bin/ledger-collab check …`** — byte semantics make BSD awk succeed, and the check then returns a REAL verdict (mine correctly read "claim … is not released or handed off" before the release). To name the offenders, decode each legacy event and print the ones that fail:
  ```sh
  for f in .context_ledger/memory/collaboration/events/*.md; do
    python3 -c "import sys;open(sys.argv[1],'rb').read().decode('utf-8')" "$f" 2>/dev/null || echo "$f"
  done
  ```
- **Prevent next time:** on macOS always invoke the collab/gate helpers with `LC_ALL=C`; treat "rc=2 + awk towc" as this trap, never as a bad event of your own making. Upstream fix worth making: have `ledger-collab-check` read events with `LC_ALL=C` itself (or validate UTF-8 and skip with a warning naming the file) so the failure is never silent.

### 2026-09-10 — Session 464 (Elena, macOS) — bankofai's configured default model is delisted; the free tier is a two-model set

- **Problem:** the live-testing protocol names `bankofai / deepseek-v4-flash` the PRIMARY live-test provider, but bankofai no longer serves `deepseek-v4-flash`. Every request using the adapter's `default_model` dies with **HTTP 400 `credit insufficient balance: balance=0`** — the error names BALANCE, so it reads as "account empty, owner must top up" when the real story is partly "this model id is gone". The app's own `~/LocalMind/settings.json` still says `adapter: bankofai` + `model: deepseek-v4-flash`, i.e. the installed app is configured for a model the provider will not serve.
- **Cost:** the S462 session burned two sessions' worth of live-test time on this, and S464 hit the same wall in its first probe.
- **Cause:** the provider rotated its catalog to `deepseek-v4.1-flash` / `deepseek-v4-pro` (both gated on balance or deposit); balance stays 0 on this account, so only the genuinely free models answer.
- **Workaround / fix:** with balance 0 on this account, exactly **`qwen3.8-flash`** and **`glm-5.3-flash`** answered; everything else returned either `Deposit required to unlock premium models` (qwen3.8-27b, glm-5.1, gpt-5-nano, deepseek-v4-pro) or a plain **429** (hy3, minimax-*, kimi-*, gemini-3-*, claude-haiku-4.5, qwen3.8-27b on retry) — a 429 there is rate limiting, not an entitlement block, so retry before concluding a model is unavailable. `/v1/models` still authenticates with a zero balance (47 ids) and is the cheap way to distinguish "key dead" from "model gone". `scripts/live_test_dir_explorer.py` now pins `bankofai -> qwen3.8-flash` (`aa08cd5`), matching `live_test_prompt_audit.py`'s existing pin.
- **Prevent next time:** never trust an adapter's `default_model` for live work — read it, then probe. Owner action still open: point the adapter default / app settings at a served model, or top the balance up.

## 2026-09-11 — Zuri / glm-5.3-flash (Session 465) — the benchmark harness silently shrank a batch on an unknown test ID

- **Problem:** `lm_benchmark.py --tests CAT14-2,CAT14-5,CAT15-1,CAT10-3` returned THREE results and a green-looking summary — CAT10-3 was silently dropped because the CAT10 category is not implemented in the harness's TESTS registry (the catalog doc lists it, the code never had it), and the ID matcher kept no record of unmatched IDs. A batch that "completed" while silently missing whole checks is worse than a failure.
- **Cost:** ~2 min (the missing test was caught only by counting results against the request).
- **Cause:** `selected = [t for t in TESTS if t["id"] in ids]` with no else-branch.
- **Workaround / fix:** fixed in-product same session (commit `71ab798e`): unknown IDs now print a WARNING naming them. General lesson stands for every "select from registry" CLI: report what did NOT match.
- **Prevent next time:** when a run's result count must equal the request count, assert it — or let the tool warn (now it does).

---
## 2026-09-11 — Asha / qwen3.8-flash (Session 467)
- **Problem:** Phase-1 read-in tried to tail five append-only logs in ONE command; output exceeded 73KB and was persisted off-context, forcing a second targeted pass. Separately, invoking `ledger-gates.ps1` directly from Git Bash dies with `/usr/bin/env: 'pwsh': No such file or directory`.
- **Cost:** ~3 extra commands.
- **Cause:** the durable logs are now 1,500+ lines deep, so multi-file bulk tails overshoot the tool-output budget; and this box has Windows PowerShell 5.1 only (`powershell`), no `pwsh` on PATH — the AGENTS/kickoff guidance to use the `.cmd` launchers exists precisely for this, re-confirmed the hard way.
- **Workaround / fix:** tail logs ONE file at a time (~4–5KB windows) or grep the section headers first; always go through the `.cmd` launchers for `.context_ledger/core/bin/*` on Windows.
- **Prevent next time:** Phase 1 already prescribes "last 3–5 entries" — slice per file, not per burst; the `.cmd` rule is standing guidance, follow it before trying the `.ps1`.

---
## 2026-09-11 — Asha / qwen3.8-flash (Session 467, 1.0.0 adoption burst)
- **Problem:** three small frictions in one burst: (1) `git push` died once with HTTP 408 (remote hangup) — retry succeeded immediately; (2) the migrated `history.conf` DISPLAYED as cp1252 mojibake (`â€"`), which read like a migration encoding bug — `od -c` showed correct UTF-8 em-dash bytes, so it was a terminal display artifact, not file corruption (a "repair" would have double-encoded the file); (3) the update flag is spelled `-Major` on the Windows ps1 port but `--major` in the POSIX port/CHANGELOG — the owner's `sh ... update core --major` form maps to `.cmd update -Major` here.
- **Cost:** ~3 extra commands, one failed push.
- **Cause:** (1) transient network; (2) the Bash tool's output pipeline renders some UTF-8 as cp1252 — file bytes and displayed bytes are not the same evidence; (3) two ports, two spellings for one switch.
- **Workaround / fix:** retry pushes once before diagnosing; verify suspect encodings with `od -c` (or `git diff`) on the BYTES before editing — and remember bare `python` is the Windows Store stub (the "repair" script silently no-opped through it; use `backend/.venv/Scripts/python.exe`); use the `.cmd` launchers and their `-Major` spelling on Windows.
- **Prevent next time:** same file-evidence discipline as the live-testing bar — display is not proof; and keep the two-spelling note next to the update instructions in `environments.md` (added).

---
## 2026-09-11 — Amir / glm-5.3-flash (Session 468) — a gate-teeth probe in a NON-REPO scratch dir cannot test configured-command verdicts (false closure almost shipped)

- **Problem:** re-testing the Windows gate-teeth flaw against core 1.0.2, I built a scratch fake-repo (no `git init`) with a one-line gates.conf whose configured command printed a line and exited 1. The wrapper returned rc=2 and I read that as "the gate now fails a chatty failing command — flaw CLOSED" and logged the closure. It was wrong twice over: (1) the rc=2 came from the *universal* `git diff --cached --check` failing in the non-repo (FAILED (129) — visible in the very output I was reading), not from the configured line, whose verdict was still masked by child-stdout contamination; (2) the control run "passed" for the same accidental reason. The real-repo pre-commit minutes later showed `FAILED (1)` → `GATE PASSED` + rc=0 on a chatty failing line — the flaw is OPEN (see flaws log S468).
- **Cost:** one false closure written and then rewritten in the flaws log; ~4 extra commands; and the closure claim was minutes from being committed and pushed.
- **Cause:** the probe changed TWO variables at once (repo-ness and the configured command) and the assertion was the wrapper's rc — an aggregate signal — instead of the specific line's verdict (`FAILED (N)` for that command / absence of `GATE PASSED` when only that line is red).
- **Workaround / fix:** corrected the flaws-log entry with the three-leg evidence (structural read of `Run-One`; a minimal probe isolating `Run-One`'s return shape: chatty failing child → `COUNT=2`/`-not`=`$false`; stderr-only child → `COUNT=1`/detected; real pre-commit demonstration).
- **Prevent next time:** a gate probe must change ONE variable and assert the SPECIFIC verdict: either `git init` the scratch repo (so the universal checks pass and the configured line is the only red), or run the probe against the real repo with a deliberately failing path — and always read the per-command `FAILED (N)`/`GATE PASSED` lines, never the wrapper rc alone (on Windows the rc is untrustworthy anyway per the open flaw).

---
## 2026-09-11 — Zawadi / glm-5.3-flash (Session 469) — worktree junction teardown on Windows

- **Problem:** two small traps in the BEFORE-worktree recipe: (1) creating the backend/.venv junction with `cmd //c 'mklink /J …'` from Git Bash opened an INTERACTIVE cmd (banner, no command executed) twice — the single-quoted compound never ran; (2) `git worktree remove` on a worktree containing the junction went through WITHOUT complaint, because `backend/.venv` is gitignored so the tree counts as clean — nothing stops the removal from racing a recursive delete into the junction TARGET (the shared main venv).
- **Cost:** ~5 minutes (two failed mklink attempts + a post-removal venv-integrity check that should not have been necessary).
- **Cause:** MSYS quoting/switch mangling for `cmd /c` compounds; gitignore making a worktree with a machine-local junction look "clean" to worktree remove.
- **Workaround / fix:** create junctions with `powershell -NoProfile -Command "New-Item -ItemType Junction -Path <link> -Target <target>"` (worked first try); remove the junction EXPLICITLY as its own step before `git worktree remove`, and verify the target venv afterwards (`python.exe --version` + site-packages count).
- **Prevent next time:** add the PowerShell junction form + explicit teardown order to the S445 worktree recipe (that entry's `mklink /J` guidance is the part that misfired from Git Bash).

---
## 2026-09-11 — Buffy / deepseek-v4-flash (Session 472) — the roster check-in edit glued my row onto a peer's row (blank-line separator consumed, not restored)

- **Problem:** adding my roster row by anchoring on the text AFTER the peer's row ("\n\n<!-- Clock-out …" — deliberately NOT spanning Kojo's line) still produced a glued row: the replacement string reproduced the two newlines AFTER my new row but not the separator it consumed, so `| Kojo … |` and `| Buffy … |` ended up on ONE line. This is the same visible symptom as Elena's S464 header/separator slip, via a different mechanism (abutting an existing block vs. anchoring after one).
- **Cost:** one verification round (diff + `awk`/`git diff --numstat` byte-level read) and one repair edit — no bad commit, because the rule's own guard (review `git diff`, expect `+1` on check-in) caught it before staging.
- **Cause:** an insertion anchored on a block-leading `\n\n` must re-emit that whitespace in the replacement; the pitfall guidance only warns about `old_string` spanning a peer's row, which I had avoided — so "I followed the rule" gave false confidence in the edit shape.
- **Workaround / fix:** repaired with a single targeted replace (`|<peer row tail> || Buffy` → `|<peer row tail> |\n| Buffy`) and confirmed `git diff --numstat` = `1  0` for the roster file. Working rule: put the consumed newline(s) at the START of any row insertion.
- **Prevent next time:** treat the roster edit as a byte operation, not a text one — after any roster insert, `git diff --numstat` must read `1 0` (or `2 1` for a "Doing"-cell update) before staging; anything else is a mangled table. Flaw entry filed with a suggested protocol/checker repair (a table-shape lint in `ledger-mem check` would catch this class mechanically).

---
## 2026-09-11 — Buffy / deepseek-v4-flash (Session 472) — `scripts/venv-run.sh` is `python -m`-only, so standalone probe scripts cannot go through it

- **Problem:** running a throwaway frozen-clock probe script via the project's venv helper (`sh scripts/venv-run.sh python /tmp/probe.py`) fails with `No module named python` — the helper always execs `python -m "$@"`, and there is no venv executable shim for running a FILE. The direct venv path then fails again with `ModuleNotFoundError: No module named 'tests'` because the helper also carried the `PYTHONPATH` (pytest's `pythonpath = ["src", ".."]`) that a bare interpreter invocation lacks.
- **Cost:** 2 extra commands on a 3-poll probe.
- **Cause:** the helper's documented contract (`<tool> [args…]`, e.g. `ruff check backend/src`) is module-based by design; probe scripts need the resolved interpreter plus the repo's import path, which live in two different places (the helper's candidate list, and `backend/pyproject.toml`'s pytest config).
- **Workaround / fix:** `PYTHONPATH="backend/src:." backend/.venv/bin/python probe.py` (POSIX) / the `Scripts/python.exe` equivalent on Windows.
- **Prevent next time:** `system/live-testing.md` should carry the one-line standalone-probe invocation alongside the pytest form — most live/verification work here ends up running a script, not a module.

---
## 2026-09-12 — Omari / glm-5.3-flash (Session 472) — three frontend-test traps cost ~30 minutes on a green change

- **Problem:** (1) I wrote new vitest fixtures as JSX attribute strings with `\n` (`thinking="- a\n- b"`) — JSX attribute string literals do NOT process escapes, so the "multi-line markdown" content arrived as a literal one-liner with a backslash-n and both tests failed against correct code. (2) The full frontend suite fails 7–9 of 426 tests NON-DETERMINISTICALLY (parallel-worker contention/hover+clipboard/timer tests): the baseline (stashed, zero my changes) failed a different overlapping set than my run, and my run's ChatMessage.test failure passed 13/13 in isolation and again later — so a single run cannot attribute failures at all. (3) The Bash tool's `cd` state persists across calls, and an absolute `cd C:\...` with unquoted backslashes loses every `\`-letter pair (`C:\Users\...` → `/c/UserstisonDev...`), producing bogus "No such file" findings (I briefly "saw" a frontend/node_modules that never existed).
- **Cost:** ~2 extra fixture-test runs + one stash baseline + one full baseline + two isolated reruns ≈ 30 minutes on a change that was green from the first tsc.
- **Cause:** (1) JSX strings are not JS strings; (2) known pre-existing test flake in this project (frontend vitest has no baseline mechanism — ci-check deliberately runs no vitest); (3) shell quoting + persisted cwd.
- **Workaround / fix:** multi-line test fixtures belong in `{'a\nb'}` expression form; failure attribution against this suite = run each suspect file ISOLATED on both trees, never compare full-suite runs; for `cd`, always the forward-slash form `/c/Users/...`.
- **Prevent next time:** when a full frontend suite goes red, suspect flake BEFORE suspecting your change if any failing file is one you did not touch; ci-check.sh deliberately runs no vitest (its ratchet covers tsc + eslint + ruff + pytest) — don't "fix" the flake by adding vitest to gates.conf without owner direction, the suite needs a determinism pass first.

---
## 2026-09-12 — Kojo / glm-5.3-flash (Session 471) — my first live harness parsed the wrong SSE field names and produced a FALSE FAIL on a working change

- **Problem:** the watchdog live trace printed `answer: "", PASS: false` while the status timeline was PERFECT (notice@5s, offer@30s, recovery). My harness read `evt.get("text")` / truthy `evt.get("done")` per SSE line; the route actually emits `{"type":"token","content":...}` and `{"type":"done"}`. A parse miss looked exactly like a product miss — one full ~75s re-run before I checked the emit sites.
- **Cost:** one extra server boot + 40s stall cycle (~90s) and 3 commands.
- **Cause:** guessed the SSE event shape from the frontend vocabulary instead of reading the producer. The route's `_sse({...})` call sites (`chat.py` — token/content ~862, status_update ~620, done ~1028) are the contract.
- **Workaround / fix:** re-run with `type=="token"→content`, `type=="done"` — clean PASS artifact in `scratch/live-watchdog-s471.json`. The cross-check that saved the diagnosis: the server log (fast-path boot + title-after-completion timestamps) already proved recovery; trust the producer-side log when the consumer-side script disagrees with it.
- **Prevent next time:** before writing ANY SSE consumer script, grep the `_sse(` / event-emission sites in the producing route for the exact event keys; never assert on guessed field names. When a verdict contradicts a flawless timeline, read the producer's log before touching the product.
